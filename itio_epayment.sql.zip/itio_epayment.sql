-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2024 at 04:15 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itio_epayment`
--

-- --------------------------------------------------------

--
-- Table structure for table `itio_activity`
--

CREATE TABLE `itio_activity` (
  `id` int(11) NOT NULL,
  `table_id` int(11) DEFAULT NULL,
  `work_title` varchar(500) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `addedby` int(11) DEFAULT NULL,
  `addedon` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_activity`
--

INSERT INTO `itio_activity` (`id`, `table_id`, `work_title`, `ip`, `addedby`, `addedon`) VALUES
(1, 11, 'Add Main Menu - epayment ', '::1', 1, '2023-11-15 04:28:13'),
(2, 53, 'Add Sub Menu - Send Payment ', '::1', 1, '2023-11-15 04:28:56'),
(3, 54, 'Add Sub Menu - Transactions ', '::1', 1, '2023-11-15 04:29:09'),
(4, 35, 'Add New User - ITIO Innovex (admin5) ', '::1', 1, '2023-11-15 04:32:55'),
(5, 35, 'Update Assign Role - {\"epayment\":\"1\",\"send-payment\":\"1\",\"transactions\":\"1\"} ', '::1', 1, '2023-11-15 04:33:06'),
(6, 1, 'Update Assign Role - {\"epayment\":\"1\",\"send-payment\":\"1\",\"transactions\":\"1\",\"menu-&-submenu\":\"1\",\"menu-manager\":\"1\",\"menu-order-manager\":\"1\",\"submenu-manager\":\"1\",\"users-&-roles\":\"1\",\"add-user\":\"1\",\"manage-user\":\"1\",\"user-logged-history\":\"1\"} ', '::1', 1, '2023-11-16 10:30:18'),
(7, 35, 'Update Assign Role - {\"epayment\":\"1\",\"send-payment\":\"1\",\"transactions\":\"1\"} ', '::1', 1, '2023-11-16 12:24:00'),
(8, 12, 'Add Main Menu - Tutorials ', '::1', 1, '2024-11-05 04:32:06'),
(9, 55, 'Add Sub Menu - tutorials-manager ', '::1', 1, '2024-11-05 04:34:01'),
(10, 56, 'Add Sub Menu - language-manager ', '::1', 1, '2024-11-05 04:34:38'),
(11, 1, 'Update Assign Role - {\"epayment\":\"1\",\"send-payment\":\"1\",\"transactions\":\"1\",\"tutorials\":\"1\",\"language-manager\":\"1\",\"tutorials-manager\":\"1\",\"menu-&-submenu\":\"1\",\"menu-manager\":\"1\",\"menu-order-manager\":\"1\",\"submenu-manager\":\"1\",\"users-&-roles\":\"1\",\"add-user\":\"1\",\"manage-user\":\"1\",\"user-logged-history\":\"1\"} ', '::1', 1, '2024-11-05 04:34:59'),
(12, 57, 'Add Sub Menu - Chat ', '::1', 1, '2024-11-05 04:35:36'),
(13, 1, 'Update Assign Role - {\"epayment\":\"1\",\"send-payment\":\"1\",\"transactions\":\"1\",\"tutorials\":\"1\",\"chat\":\"1\",\"language-manager\":\"1\",\"tutorials-manager\":\"1\",\"menu-&-submenu\":\"1\",\"menu-manager\":\"1\",\"menu-order-manager\":\"1\",\"submenu-manager\":\"1\",\"users-&-roles\":\"1\",\"add-user\":\"1\",\"manage-user\":\"1\",\"user-logged-history\":\"1\"} ', '::1', 1, '2024-11-05 04:35:44'),
(14, 56, 'Update Sub Menu - Tutorial Manager ', '::1', 1, '2024-11-05 04:50:01'),
(15, 55, 'Update Sub Menu - Tutorial Menu Manager ', '::1', 1, '2024-11-05 04:50:19'),
(16, 58, 'Add Sub Menu - Add Tutorial ', '::1', 1, '2024-11-05 04:50:58'),
(17, 59, 'Add Sub Menu - Tutorials List Manager ', '::1', 1, '2024-11-05 04:52:00'),
(18, 56, 'Update Sub Menu - Tutorial Title Manager ', '::1', 1, '2024-11-05 04:52:36'),
(19, 1, 'Update Assign Role - {\"epayment\":\"1\",\"send-payment\":\"1\",\"transactions\":\"1\",\"tutorials\":\"1\",\"add-tutorial\":\"1\",\"chat\":\"1\",\"tutorial-menu-manager\":\"1\",\"tutorial-title-manager\":\"1\",\"tutorials-list-manager\":\"1\",\"menu-&-submenu\":\"1\",\"menu-manager\":\"1\",\"menu-order-manager\":\"1\",\"submenu-manager\":\"1\",\"users-&-roles\":\"1\",\"add-user\":\"1\",\"manage-user\":\"1\",\"user-logged-history\":\"1\"} ', '::1', 1, '2024-11-05 04:53:01'),
(20, 57, 'Delete - Submenu', '::1', 1, '2024-11-05 05:06:14'),
(21, 1, 'Add Main Title - GoLang ', '::1', 1, '2024-11-05 05:17:57'),
(22, 1, 'Update Main Title - GoLang44 ', '::1', 1, '2024-11-05 05:18:05'),
(23, 1, 'Update Main Title - GoLang ', '::1', 1, '2024-11-05 05:18:10'),
(24, 2, 'Add Main Title - PHP ', '::1', 1, '2024-11-05 05:19:12'),
(25, 1, 'Add Sub Menu - ssss ', '::1', 1, '2024-11-05 10:34:29'),
(26, 2, 'Add Sub Menu - vvvvv ', '::1', 1, '2024-11-05 10:38:57'),
(27, 2, 'Update Sub Menu - vvvvvxx ', '::1', 1, '2024-11-05 10:39:24'),
(28, 1, 'Update Sub Menu - ssssvv ', '::1', 1, '2024-11-05 10:39:32'),
(29, 2, 'Delete - Tutorial_menu', '::1', 1, '2024-11-05 10:39:39'),
(30, 3, 'Add Sub Menu - sdfsdfsdfsd ', '::1', 1, '2024-11-25 17:10:09');

-- --------------------------------------------------------

--
-- Table structure for table `itio_admin`
--

CREATE TABLE `itio_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_user` varchar(50) NOT NULL,
  `admin_pass` varchar(100) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `admin_mobile` varchar(12) NOT NULL,
  `admin_email` varchar(100) DEFAULT NULL,
  `admin_address` varchar(200) DEFAULT NULL,
  `admin_designation` varchar(100) DEFAULT NULL,
  `admin_profile_pic` varchar(200) DEFAULT NULL,
  `admin_roles` text DEFAULT NULL,
  `admin_type` varchar(10) NOT NULL DEFAULT '0',
  `admin_status` int(1) NOT NULL DEFAULT 1,
  `admin_addedby` int(11) DEFAULT NULL,
  `admin_addedon` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `itio_admin`
--

INSERT INTO `itio_admin` (`admin_id`, `admin_user`, `admin_pass`, `admin_name`, `admin_mobile`, `admin_email`, `admin_address`, `admin_designation`, `admin_profile_pic`, `admin_roles`, `admin_type`, `admin_status`, `admin_addedby`, `admin_addedon`) VALUES
(1, 'vikash', 'e20383708e67d5f9bf1c03944bf191d1d5bee069e05d9dff453cbfdbcb37de02', 'Vikash Kumar Gupta', '955553874066', 'vikashg@bigit.io', 'India 110088 55 T6', 'Web Developer22 8888', NULL, '{\"epayment\":\"1\",\"send-payment\":\"1\",\"transactions\":\"1\",\"tutorials\":\"1\",\"add-tutorial\":\"1\",\"chat\":\"1\",\"tutorial-menu-manager\":\"1\",\"tutorial-title-manager\":\"1\",\"tutorials-list-manager\":\"1\",\"menu-&-submenu\":\"1\",\"menu-manager\":\"1\",\"menu-order-manager\":\"1\",\"submenu-manager\":\"1\",\"users-&-roles\":\"1\",\"add-user\":\"1\",\"manage-user\":\"1\",\"user-logged-history\":\"1\"}', '11', 1, 1, '2024-11-05 04:53:01'),
(35, 'admin', 'e20383708e67d5f9bf1c03944bf191d1d5bee069e05d9dff453cbfdbcb37de02', 'ITIO Innovex', '09555538740', 'vikashg@itio.in', 'Noida Sec 65', NULL, NULL, '{\"epayment\":\"1\",\"send-payment\":\"1\",\"transactions\":\"1\"}', '2', 1, 1, '2023-11-15 04:33:35');

-- --------------------------------------------------------

--
-- Table structure for table `itio_login_master`
--

CREATE TABLE `itio_login_master` (
  `id` int(11) NOT NULL,
  `user_id` int(5) NOT NULL,
  `log_ip` varchar(20) NOT NULL,
  `log_on` datetime NOT NULL,
  `log_out` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `itio_login_master`
--

INSERT INTO `itio_login_master` (`id`, `user_id`, `log_ip`, `log_on`, `log_out`) VALUES
(1, 1, '::1', '2023-11-15 09:52:05', '2023-11-15 10:00:10'),
(2, 1, '::1', '2023-11-15 10:00:59', '2023-11-15 10:01:08'),
(3, 1, '::1', '2023-11-15 10:01:18', '2023-11-15 10:03:11'),
(4, 35, '::1', '2023-11-15 10:04:00', '2023-11-15 11:44:55'),
(5, 1, '::1', '2023-11-15 11:45:04', '2023-11-15 11:45:41'),
(6, 1, '::1', '2023-11-16 15:59:09', '2023-11-16 16:00:23'),
(7, 1, '::1', '2023-11-16 16:00:28', NULL),
(8, 1, '49.36.180.154', '2023-11-16 12:34:17', '2023-11-16 12:34:37'),
(9, 35, '49.36.180.154', '2023-11-16 12:34:45', '2023-11-16 12:44:39'),
(10, 1, '47.31.179.10', '2023-12-11 16:46:18', NULL),
(11, 1, '49.36.177.64', '2024-03-28 11:57:52', NULL),
(12, 1, '160.202.37.7', '2024-04-11 11:14:48', NULL),
(13, 1, '122.176.17.22', '2024-09-16 17:18:43', '2024-09-16 17:19:43'),
(14, 1, '::1', '2024-11-04 15:29:51', '2024-11-04 15:31:43'),
(15, 1, '::1', '2024-11-04 15:31:48', '2024-11-04 15:31:54'),
(16, 1, '::1', '2024-11-04 15:32:11', '2024-11-04 15:32:14'),
(17, 1, '::1', '2024-11-04 15:32:19', '2024-11-04 16:07:07'),
(18, 1, '::1', '2024-11-05 09:57:46', '2024-11-05 10:05:04'),
(19, 1, '::1', '2024-11-05 10:05:05', '2024-11-05 10:05:47'),
(20, 1, '::1', '2024-11-05 10:05:48', '2024-11-05 10:23:05'),
(21, 1, '::1', '2024-11-05 10:23:06', '2024-11-05 10:31:01'),
(22, 1, '::1', '2024-11-05 10:31:03', '2024-11-05 10:31:56'),
(23, 1, '::1', '2024-11-05 10:31:58', NULL),
(24, 1, '::1', '2024-11-05 16:00:41', NULL),
(25, 1, '::1', '2024-11-05 16:43:07', NULL),
(26, 1, '::1', '2024-11-05 22:59:00', NULL),
(27, 1, '::1', '2024-11-25 22:39:50', NULL),
(28, 1, '::1', '2024-11-26 08:40:42', NULL),
(29, 1, '::1', '2024-11-29 08:37:15', '2024-11-29 08:39:15'),
(30, 1, '::1', '2024-11-29 08:40:05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `itio_master_trans_table`
--

CREATE TABLE `itio_master_trans_table` (
  `transaction_id` int(11) NOT NULL,
  `member_id` int(20) NOT NULL,
  `transaction_type` varchar(25) DEFAULT NULL,
  `transaction_for` varchar(25) DEFAULT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_currency` varchar(20) DEFAULT NULL,
  `transaction_amount` decimal(10,2) DEFAULT NULL,
  `converted_transaction_currency` varchar(20) DEFAULT NULL,
  `converted_transaction_amount` decimal(10,2) DEFAULT NULL,
  `transaction_bank_name` varchar(255) DEFAULT NULL,
  `transaction_ac_no` varchar(50) DEFAULT NULL,
  `transaction_swift_code` varchar(20) DEFAULT NULL,
  `transaction_bank_address` varchar(255) DEFAULT NULL,
  `transaction_bank_id` int(11) DEFAULT NULL,
  `transaction_purpose` varchar(255) DEFAULT NULL,
  `usr_name` varchar(50) DEFAULT NULL,
  `usr_address` varchar(255) DEFAULT NULL,
  `usr_descricption` varchar(255) DEFAULT NULL,
  `admin_transaction_id` varchar(50) DEFAULT NULL,
  `admin_transaction_desc` text DEFAULT NULL,
  `admin_approval_status` varchar(255) DEFAULT NULL,
  `admin_transaction_date` datetime DEFAULT NULL,
  `transaction_fee_linked_account` varchar(50) DEFAULT NULL,
  `transaction_status` varchar(55) NOT NULL DEFAULT 'Process',
  `available_balance` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `itio_master_trans_table`
--

INSERT INTO `itio_master_trans_table` (`transaction_id`, `member_id`, `transaction_type`, `transaction_for`, `transaction_date`, `transaction_currency`, `transaction_amount`, `converted_transaction_currency`, `converted_transaction_amount`, `transaction_bank_name`, `transaction_ac_no`, `transaction_swift_code`, `transaction_bank_address`, `transaction_bank_id`, `transaction_purpose`, `usr_name`, `usr_address`, `usr_descricption`, `admin_transaction_id`, `admin_transaction_desc`, `admin_approval_status`, `admin_transaction_date`, `transaction_fee_linked_account`, `transaction_status`, `available_balance`) VALUES
(1, 1, 'Credit', 'Add Money', '2023-07-24 10:45:25', 'USD', 5000.00, 'USD', 5000.00, 'HBSC', '110052525255', '653265', 'Noida Sector 69 UP', 2, NULL, 'vikash', 'Delhii', 'Test Desc', '1', 'test data', 'Added On 24-07-2023 10:48:00 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 10:48:00', NULL, 'Success', '5000'),
(2, 1, 'Debit', 'Quick Transfer', '2023-07-24 10:45:59', 'USD', 250.00, 'USD', 250.00, 'IDFC', '3265326532', '123456', 'Noida sector 65', NULL, 'New Test', 'Ramesh Choudhary', '', NULL, '2', 'hiiiiiiiii', 'Added On 24-07-2023 10:49:13 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 10:49:13', NULL, 'Success', '4650'),
(3, 1, 'Debit', 'Request Money', '2023-07-24 10:46:27', 'USD', 200.00, 'USD', 200.00, 'HBSC', '110052525255', '653265', 'Noida Sector 69 UP', 2, NULL, 'vikash', 'Delhii', 'Test Desc', '3', 'hhhhhhhhhhhhhh', 'Added On 24-07-2023 10:49:36 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 10:49:36', NULL, 'Success', '4425'),
(4, 1, 'Debit', 'Beneficiary Transfer', '2023-07-24 10:46:49', 'USD', 105.00, 'USD', 105.00, 'PNB', '3265236532', '235626', 'Noida sector 65', NULL, 'New Test', '', 'Noida sec 69', NULL, '4', 'hellloooooooooooo', 'Added On 24-07-2023 10:50:04 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 10:50:04', NULL, 'Success', '4295'),
(5, 1, 'Debit', 'Transaction Fee', '2023-07-24 10:48:00', 'USD', 100.00, 'USD', 100.00, 'HDFC', '9000008080805', 'HDFC5005', 'B-78 Connaught Place New Delhi India  110001', NULL, 'Assign Transaction Fee of TransID - 1  is MDR 2.00 % : 100 USD', 'ITIO INNOVEX PVT LTD', 'ITIO Tower C32, Kaushambi, Ghaziabad, Uttar Pradesh 201010', NULL, NULL, 'Auto Deduct Transaction Fee and Added on Admin Bank Account', 'Added On 24-07-2023 10:48:00 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 10:48:02', '1', 'Success', '4900'),
(6, 1, 'Debit', 'Transaction Fee', '2023-07-24 10:49:13', 'USD', 25.00, 'USD', 25.00, 'HDFC', '9000008080805', 'HDFC5005', 'B-78 Connaught Place New Delhi India  110001', NULL, 'Transaction Fee of TransID - 2 is Min Amount : 25 USD', 'ITIO INNOVEX PVT LTD', 'ITIO Tower C32, Kaushambi, Ghaziabad, Uttar Pradesh 201010', NULL, NULL, 'Auto Deduct Transaction Fee and Added on Admin Bank Account', 'Added On 24-07-2023 10:49:13 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 10:49:15', '2', 'Success', '4625'),
(7, 1, 'Debit', 'Transaction Fee', '2023-07-24 10:49:36', 'USD', 25.00, 'USD', 25.00, 'HDFC', '9000008080805', 'HDFC5005', 'B-78 Connaught Place New Delhi India  110001', NULL, 'Transaction Fee of TransID - 3 is Min Amount : 25 USD', 'ITIO INNOVEX PVT LTD', 'ITIO Tower C32, Kaushambi, Ghaziabad, Uttar Pradesh 201010', NULL, NULL, 'Auto Deduct Transaction Fee and Added on Admin Bank Account', 'Added On 24-07-2023 10:49:36 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 10:49:38', '3', 'Success', '4400'),
(8, 1, 'Debit', 'Transaction Fee', '2023-07-24 10:50:04', 'USD', 25.00, 'USD', 25.00, 'HDFC', '9000008080805', 'HDFC5005', 'B-78 Connaught Place New Delhi India  110001', NULL, 'Transaction Fee of TransID - 4 is Min Amount : 25 USD', 'ITIO INNOVEX PVT LTD', 'ITIO Tower C32, Kaushambi, Ghaziabad, Uttar Pradesh 201010', NULL, NULL, 'Auto Deduct Transaction Fee and Added on Admin Bank Account', 'Added On 24-07-2023 10:50:04 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 10:50:06', '4', 'Success', '4270'),
(9, 1, 'Credit', 'Add Money', '2023-07-24 11:20:44', 'USD', 580.00, 'USD', 580.00, 'HBSC', '110052525255', '653265', 'Noida Sector 69 UP', 2, NULL, 'vikash', 'Delhii', 'Test Desc', '9', 'testtttt', 'Added On 26-07-2023 17:19:07 with IP : 127.0.0.1 By Demo Admin', '2023-07-26 17:19:07', NULL, 'Success', '4040'),
(10, 1, 'Debit', 'Request Money', '2023-07-24 11:47:20', 'USD', 333.00, 'USD', 330.00, 'HBSC', '110052525255', '653265', 'Noida Sector 69 UP', 2, NULL, 'vikash', 'Delhii', 'Test Desc', '10', 'test', 'Added On 24-07-2023 14:19:27 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 14:19:27', NULL, 'Success', '3660'),
(11, 1, 'Debit', 'Quick Transfer', '2023-07-24 12:06:16', 'USD', 225.00, 'USD', 255.00, 'IDFC', '3223233232', '123456', 'Noida sector 65', NULL, 'New Test', 'Ramesh Choudhary', '', NULL, '11', '77777777', 'Added On 24-07-2023 13:44:30 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 13:44:30', NULL, 'Success', '4015'),
(12, 1, 'Debit', 'Transaction Fee', '2023-07-24 13:44:30', 'USD', 25.00, 'USD', 25.00, 'HDFC', '9000008080805', 'HDFC5005', 'B-78 Connaught Place New Delhi India  110001', NULL, 'Transaction Fee of TransID - 11 is Min Amount : 25 USD', 'ITIO INNOVEX PVT LTD', 'ITIO Tower C32, Kaushambi, Ghaziabad, Uttar Pradesh 201010', NULL, NULL, 'Auto Deduct Transaction Fee and Added on Admin Bank Account', 'Added On 24-07-2023 13:44:30 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 13:44:32', '11', 'Success', '3990'),
(13, 1, 'Debit', 'Transaction Fee', '2023-07-24 14:19:27', 'USD', 25.00, 'USD', 25.00, 'HDFC', '9000008080805', 'HDFC5005', 'B-78 Connaught Place New Delhi India  110001', NULL, 'Transaction Fee of TransID - 10 is Min Amount : 25 USD', 'ITIO INNOVEX PVT LTD', 'ITIO Tower C32, Kaushambi, Ghaziabad, Uttar Pradesh 201010', NULL, NULL, 'Auto Deduct Transaction Fee and Added on Admin Bank Account', 'Added On 24-07-2023 14:19:27 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 14:19:29', '10', 'Success', '3635'),
(14, 1, 'Debit', 'Request Money', '2023-07-24 15:03:49', 'USD', 150.00, 'USD', 150.00, 'HBSC', '110052525255', '653265', 'Noida Sector 69 UP', 2, NULL, 'vikash', 'Delhii', 'Test Desc', '14', 'trrterer', 'Added On 24-07-2023 15:22:03 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 15:22:03', NULL, 'Success', '3485'),
(15, 1, 'Debit', 'Transaction Fee', '2023-07-24 15:22:03', 'USD', 25.00, 'USD', 25.00, 'HDFC', '9000008080805', 'HDFC5005', 'B-78 Connaught Place New Delhi India  110001', NULL, 'Transaction Fee of TransID - 14 is Min Amount : 25 USD', 'ITIO INNOVEX PVT LTD', 'ITIO Tower C32, Kaushambi, Ghaziabad, Uttar Pradesh 201010', NULL, NULL, 'Auto Deduct Transaction Fee and Added on Admin Bank Account', 'Added On 24-07-2023 15:22:03 with IP : 127.0.0.1 By Vikash Gupta', '2023-07-24 15:22:05', '14', 'Success', '3460'),
(16, 1, 'Debit', 'Transaction Fee', '2023-07-26 17:19:07', 'USD', 20.00, 'USD', 20.00, 'HDFC', '9000008080805', 'HDFC5005', 'B-78 Connaught Place New Delhi India  110001', NULL, 'Transaction Fee of TransID - 9 is Min Amount : 20 USD', 'ITIO INNOVEX PVT LTD', 'ITIO Tower C32, Kaushambi, Ghaziabad, Uttar Pradesh 201010', NULL, NULL, 'Auto Deduct Transaction Fee and Added on Admin Bank Account', 'Added On 26-07-2023 17:19:07 with IP : 127.0.0.1 By Demo Admin', '2023-07-26 17:19:09', '9', 'Success', '4020');

-- --------------------------------------------------------

--
-- Table structure for table `itio_menu`
--

CREATE TABLE `itio_menu` (
  `menu_id` int(11) NOT NULL,
  `menu_title` varchar(200) NOT NULL,
  `menu_icon` varchar(100) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `priority` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_menu`
--

INSERT INTO `itio_menu` (`menu_id`, `menu_title`, `menu_icon`, `status`, `priority`) VALUES
(6, 'Menu & Submenu', 'fa-solid fa-bars', 1, 2),
(8, 'Users & Roles', 'fa-solid fa-user-group', 1, 5),
(11, 'epayment', 'fa-brands fa-amazon-pay', 1, 0),
(12, 'Tutorials', 'fa-solid fa-book', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `itio_submenu`
--

CREATE TABLE `itio_submenu` (
  `submenu_id` int(11) NOT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `submenu_title` varchar(200) DEFAULT NULL,
  `status` int(1) DEFAULT 1,
  `addedby` int(11) NOT NULL,
  `addedon` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_submenu`
--

INSERT INTO `itio_submenu` (`submenu_id`, `menu_id`, `submenu_title`, `status`, `addedby`, `addedon`) VALUES
(13, 6, 'Submenu Manager', 1, 0, '2023-09-30 07:05:47'),
(14, 6, 'Menu Manager', 1, 0, '2023-09-30 07:05:59'),
(15, 8, 'Add User', 1, 0, '2023-09-30 07:06:39'),
(16, 8, 'Manage User', 1, 0, '2023-09-30 07:07:04'),
(17, 8, 'Manage Roles', 2, 0, '2023-10-03 08:55:22'),
(18, 6, 'Menu Order Manager', 1, 0, '2023-10-03 09:01:34'),
(51, 8, 'User Logged History', 1, 0, '2023-10-25 06:13:38'),
(53, 11, 'Send Payment', 1, 0, '2023-11-15 04:28:56'),
(54, 11, 'Transactions', 1, 0, '2023-11-15 04:29:09'),
(55, 12, 'Tutorial Menu Manager', 1, 0, '2024-11-05 04:50:19'),
(56, 12, 'Tutorial Title Manager', 1, 0, '2024-11-05 04:52:36'),
(57, 12, 'Chat', 2, 0, '2024-11-05 05:06:14'),
(58, 12, 'Add Tutorial', 1, 0, '2024-11-05 04:50:58'),
(59, 12, 'Tutorials List Manager', 1, 0, '2024-11-05 04:52:00');

-- --------------------------------------------------------

--
-- Table structure for table `itio_tutorial_master`
--

CREATE TABLE `itio_tutorial_master` (
  `tutorial_id` int(11) NOT NULL,
  `tutorial_menu` int(11) DEFAULT NULL,
  `tutorial_submenu` int(11) DEFAULT NULL,
  `tutorial_title` varchar(255) DEFAULT NULL,
  `tutorial_desc1` text DEFAULT NULL,
  `tutorial_desc2` text DEFAULT NULL,
  `tutorial_desc3` text DEFAULT NULL,
  `tutorial_desc4` text DEFAULT NULL,
  `tutorial_desc5` text DEFAULT NULL,
  `tutorial_image` varchar(255) DEFAULT NULL,
  `tutorial_status` int(1) NOT NULL DEFAULT 1,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_tutorial_master`
--

INSERT INTO `itio_tutorial_master` (`tutorial_id`, `tutorial_menu`, `tutorial_submenu`, `tutorial_title`, `tutorial_desc1`, `tutorial_desc2`, `tutorial_desc3`, `tutorial_desc4`, `tutorial_desc5`, `tutorial_image`, `tutorial_status`, `timestamp`) VALUES
(1, 2, 1, 'hiiii', 'xcvxzvvcncn', '', '', '', '', NULL, 1, '2024-11-05 17:29:04'),
(2, 2, 1, 'New test', '1111111111111111', '222222222222222222', '333333333333333', '444444444444444', '55555555555555555', NULL, 1, '2024-11-05 17:29:46'),
(3, 2, 1, 'image test', 'testtt', '', '', '', '', '507856_bg-one.jpg', 1, '2024-11-05 17:37:12');

-- --------------------------------------------------------

--
-- Table structure for table `itio_tutorial_menu`
--

CREATE TABLE `itio_tutorial_menu` (
  `id` int(11) NOT NULL,
  `title_id` int(11) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `status` int(1) DEFAULT 1,
  `addedby` int(11) NOT NULL,
  `addedon` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_tutorial_menu`
--

INSERT INTO `itio_tutorial_menu` (`id`, `title_id`, `title`, `status`, `addedby`, `addedon`) VALUES
(1, 2, 'ssssvv', 1, 0, '2024-11-05 10:39:32'),
(2, 2, 'vvvvvxx', 2, 0, '2024-11-05 10:39:39'),
(3, 2, 'sdfsdfsdfsd', 1, 0, '2024-11-25 17:10:09');

-- --------------------------------------------------------

--
-- Table structure for table `itio_tutorial_title`
--

CREATE TABLE `itio_tutorial_title` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `priority` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_tutorial_title`
--

INSERT INTO `itio_tutorial_title` (`id`, `title`, `icon`, `status`, `priority`) VALUES
(1, 'GoLang', '', 1, 0),
(2, 'PHP', '', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `itio_activity`
--
ALTER TABLE `itio_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itio_admin`
--
ALTER TABLE `itio_admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `admin_user` (`admin_user`);

--
-- Indexes for table `itio_login_master`
--
ALTER TABLE `itio_login_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itio_master_trans_table`
--
ALTER TABLE `itio_master_trans_table`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `itio_menu`
--
ALTER TABLE `itio_menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `itio_submenu`
--
ALTER TABLE `itio_submenu`
  ADD PRIMARY KEY (`submenu_id`);

--
-- Indexes for table `itio_tutorial_master`
--
ALTER TABLE `itio_tutorial_master`
  ADD PRIMARY KEY (`tutorial_id`);

--
-- Indexes for table `itio_tutorial_menu`
--
ALTER TABLE `itio_tutorial_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itio_tutorial_title`
--
ALTER TABLE `itio_tutorial_title`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `itio_activity`
--
ALTER TABLE `itio_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `itio_admin`
--
ALTER TABLE `itio_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `itio_login_master`
--
ALTER TABLE `itio_login_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `itio_master_trans_table`
--
ALTER TABLE `itio_master_trans_table`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `itio_menu`
--
ALTER TABLE `itio_menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `itio_submenu`
--
ALTER TABLE `itio_submenu`
  MODIFY `submenu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `itio_tutorial_master`
--
ALTER TABLE `itio_tutorial_master`
  MODIFY `tutorial_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `itio_tutorial_menu`
--
ALTER TABLE `itio_tutorial_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `itio_tutorial_title`
--
ALTER TABLE `itio_tutorial_title`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
