<?php
$page_limit="50";

//Encryption Value
function encryption_value($rec_data){
$ciphering_value = "AES-128-CTR";
$encryption_key ="ITIO";
$encryption_value = @openssl_encrypt($rec_data, $ciphering_value, $encryption_key); 
return $encryption_value;
}

//Decryption Value
function decryption_value($rec_data){
$ciphering_value = "AES-128-CTR";
$decryption_key ="ITIO";
$decryption_value = @openssl_decrypt($rec_data, $ciphering_value, $decryption_key);
return $decryption_value;
}

//generate password
function hash_f($password){
	$result=$password;
	if($password){
		$result=hash('sha256', $password);	
	}
	return $result;
}

// Fetch Email Template
function get_email_template($template){
global $con;

$query = "SELECT `template_subject`,`template_desc` FROM `itio_email_template` WHERE `template_code`='$template'";
$result=mysqli_fetch_assoc(mysqli_query($con,$query));
return $result;
}

// Fetch USER Detail BY ID
function get_user_detail_by_id($mid,$field_name){
global $con;
$query = "SELECT $field_name FROM `itio_admin` WHERE `admin_id`='$mid' LIMIT 0,1";
$result=mysqli_fetch_assoc(mysqli_query($con,$query));
return $result;
}

// Fetch USER Exist or Not
function check_user_exist($user_name){
global $con;
$query = "SELECT admin_user FROM `itio_admin` WHERE `admin_user`='$user_name' LIMIT 0,1";
$result=mysqli_num_rows(mysqli_query($con,$query));
return $result;
}

// Fetch USER Field BY ID
function get_user_field_by_id($mid,$field_name){
global $con;
$query = "SELECT $field_name FROM `itio_admin` WHERE `admin_id`='$mid' LIMIT 0,1";
$result=mysqli_fetch_assoc(mysqli_query($con,$query));
return $result[$field_name];
}

// Fetch Table List
function get_table_list($table_name,$fetch_fields,$where_condation,$number_of_records,$page){
global $con;
global $page_limit;

if(!isset($fetch_fields)&&empty($fetch_fields)){
$fetch_fields="*";
}

if(isset($number_of_records)&&$number_of_records){
if($number_of_records==-2){
$number_of_records=" LIMIT 0,1";
}else if($number_of_records==-5){
$number_of_records=" LIMIT 0,5";
}else if($number_of_records==-10){
$number_of_records=" LIMIT 0,10";
}else{
$number_of_records=($number_of_records - 1) * $page_limit; 
$number_of_records=" LIMIT ".$number_of_records.",".$page_limit;
//$number_of_records=" LIMIT 0,".$page_limit;
}
}

if(isset($where_condation)&&$where_condation){
$where_condation=$where_condation;
}

if(isset($page)&&$page){
$cnt_query = "SELECT {$fetch_fields} FROM `{$table_name}` WHERE 1 {$where_condation} ";
$result[0]['count']=mysqli_num_rows(mysqli_query($con,$cnt_query));
}

$query = "SELECT {$fetch_fields} FROM `{$table_name}` WHERE 1 {$where_condation} {$number_of_records} ";
if(isset($_REQUEST['print'])&&$_REQUEST['print']){
echo @$cnt_query."<br>";
echo @$query."<br>";
}
$qr=mysqli_query($con,$query);
//$rs=mysqli_fetch_array($result);
$count=mysqli_num_rows($qr);

        for($i=0; $i<$count; $i++){
			$record=@mysqli_fetch_array($qr, MYSQLI_ASSOC);
			foreach($record as $key=>$value)
			{$result[$i][$key]=$value;}
		}
		
return @$result;
}

// Fetch Menu Title
function get_menu_title($menuid){
global $con;
$query = "SELECT `menu_title` FROM `itio_menu` WHERE `menu_id`='$menuid'";
$result=mysqli_fetch_array(mysqli_query($con,$query));
$menu_title=$result['menu_title'];
return $menu_title;
}

// Fetch Menu Title
function get_tutorials_title($menuid){
global $con;
$query = "SELECT `title` FROM `itio_tutorial_title` WHERE `id`='$menuid'";
$result=mysqli_fetch_array(mysqli_query($con,$query));
$menu_title=$result['title'];
return $menu_title;
}

// Fetch Menu ID By title
function get_tutorials_id($menutitle){
global $con;
$query = "SELECT `id`,`title` FROM `itio_tutorial_title` WHERE `title`='$menutitle'";
$result=mysqli_fetch_array(mysqli_query($con,$query));
$data=$result['id']."||".$result['title'];
return $data;
}

// fetch json data for assign role
function fetch_json_data($uid){
global $con;
$query = "SELECT `admin_roles` FROM `itio_admin` WHERE `admin_id`='$uid'";
$result=mysqli_fetch_array(mysqli_query($con,$query));
$admin_roles=$result['admin_roles'];
$admin_roles = json_decode($admin_roles, true);
return $admin_roles;
}

// Delete Table Data
function delete_table_data($tablename,$tableid,$field="id"){
global $con;
global $loged_user;
$query = "UPDATE `{$tablename}` SET `status`=2 WHERE `{$field}`='{$tableid}'";
$result=mysqli_query($con,$query);
$activity_title=ucwords(str_replace("itio_","",$tablename));
add_activity($loged_user,"Delete - $activity_title",$tableid);
return $act=1;
}

// Count Table Data
function count_table_data($tablename,$where){
global $con;
$cnt_query = "SELECT * FROM `{$tablename}` WHERE 1 $where ";
if(isset($_REQUEST['print'])&&$_REQUEST['print']){ echo @$cnt_query."<br>"; }
$result=mysqli_num_rows(mysqli_query($con,$cnt_query));
return $result;
}

// Update USER STATUS
function user_status($userid,$status){
global $con;
$query = "UPDATE `itio_admin` SET `admin_status`={$status} WHERE `admin_id`='{$userid}'";
$result=mysqli_query($con,$query);
return $act=1;
}

// Insert Activity
function add_activity($addedby,$work_title,$table_id){
global $con;

$ip=$_SERVER["REMOTE_ADDR"];
$query = "INSERT INTO `itio_activity` SET `table_id`='$table_id',
										  `work_title`='$work_title',
										  `addedby`='$addedby',
										  `ip`='$ip'";
$result=mysqli_query($con,$query);
return $act=1;
}

// Make Url from string
function make_url($string){
$string = trim(str_replace(array(" ", "_"), '-', strtolower($string)) );
return $string;
}

// Make Url with https://
function make_url_with_https($url){

if(!strstr($url,"http")){
$url="https://".$url;
}

return $url;
}

// Check Page view Permission
function check_permission($page){

$roles=$_SESSION['loged_user']['admin_roles'];
$roles_list = json_decode($roles,1);
if(isset($roles_list[$page]) && $roles_list[$page] == 1) {
    //$page="Authrized";
}else{
	$_SESSION['missing-page']=$page;
	header("location:missing.php");exit;
}

//return $page;
}
//The function prndate() return the date in customized format with second if DATE is valid, return '---' if not a valid DATE.
function prndates($date,$time=0){ 
	if($date=='0000-00-00 00:00:00'){
	return '---';
	}else if($time==1){ 
	return date('m/d/y H:i:s', strtotime($date));
	}else{ 
	return date('m/d/y', strtotime($date));
	}
}

function randomPassword() {
    $pass=rand(10000000,99999999);
    return $pass;
}



//This function is used to fetch list of fields
function get_select_list($tblname,$fields='*',$where_pred=''){
	global $data;
	$table_list=db_rows("SELECT $fields FROM `$tblname` WHERE 1 ".$where_pred,0);
	return $table_list;	//return subadmin list
}

//Get Menu Title
function getmenutitle($tableid){
global $con;
$rs=mysqli_fetch_array(mysqli_query($con,"SELECT `title` FROM `itio_tutorial_title` WHERE `id`='$tableid'"));
$result=$rs['title'];
return $result;
}

//Get SUb Menu Title
function getsubmenutitle($tableid){
global $con;
$rs=mysqli_fetch_array(mysqli_query($con,"SELECT `title` FROM `itio_tutorial_menu` WHERE `id`='$tableid'"));
$result=$rs['title'];
return $result;
}



?>