jQuery(function(e){
    'use strict';
    $(document).ready(function() {
        $('#summernote').summernote();
    });
  });