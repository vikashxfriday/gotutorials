<div class="main-footer text-center">
  <div class="container">
    <div class="row row-sm">
      <div class="col-md-12"> <span>Copyright &copy;2023
        
        <a href="#">ITIO</a> All rights reserved.</span> </div>
    </div>
  </div>
</div>
<!-- Listing Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content modal-content-demo">
      <div class="modal-header">
        <h6 class="modal-title">Large Modal</h6>
        <button aria-label="Close" class="btn-close" data-bs-dismiss="modal" type="button"> <span aria-hidden="true">X</span> </button>
      </div>
      <div class="modal-body">
        ============================
      </div>
      <div class="modal-footer">
        <?php /*?><button class="btn ripple btn-primary" type="button">Save changes</button><?php */?>
        <button class="btn ripple btn-secondary" data-bs-dismiss="modal" type="button">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- Listing Modal End -->

