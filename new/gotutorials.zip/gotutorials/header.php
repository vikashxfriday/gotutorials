<!-- header area start -->
   <header>
      <div class="tp-header__area tp-header__transparent">
         <div class="tp-header__main" id="header-sticky">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-6 col-6">
                     <div class="logo has-border">
                        <a href="index.html">
                           <img src="<?=$host;?>/assets/img/logo/go-logo.png" alt="logo" >
                        </a>
                     </div>
                  </div>
                  <div class="col-xxl-8 col-xl-8 col-lg-8 d-none d-lg-block">
                     <div class="main-menu">
                        <nav id="mobile-menu">
                           <ul>
                              <li class="has-dropdown">
                                 <a href="index">Languages</a>
                                 <ul class="submenu">
                                    <li><a href="/Golang">Golang</a></li>
                                    <li><a href="/PHP">PHP</a></li>
                                 </ul>
                              </li>
                              
                              <li class="has-dropdown">
                                 <a href="Web Technologies">Web Technologies</a>
                                 <ul class="submenu">
<li><a href="/HTML">HTML</a></li>
<li><a href="/CSS">CSS</a></li>
<li><a href="/JavaScript">JavaScript</a></li>
<li><a href="/TypeScript">TypeScript</a></li>
<li><a href="/ReactJS">ReactJS</a></li>
<li><a href="/NextJS">NextJS</a></li>
<li><a href="/NodeJs">NodeJs</a></li>
<li><a href="/Bootstrap">Bootstrap</a></li>

                                 </ul>
                              </li>
                              <li class="has-dropdown">
                                 <a href="#">DevOps</a>
                                 <ul class="submenu">
                                    <li><a href="/Git">Git</a></li>
                                    <li><a href="/AWS">AWS</a></li>
                                    <li><a href="/Docker">Docker</a></li>
                                    <li><a href="/Kubernetes">Kubernetes</a></li>
                                    <li><a href="/Azure">Azure</a></li>
                                    <li><a href="/GCP">GCP</a></li>
                                    
                                 </ul>
                              </li>
                              <li class="has-dropdown">
                                 <a href="">Databases</a>
                                 <ul class="submenu">
                                    <li><a href="/SQL/">SQL</a></li>
                                    <li><a href="/MYSQL/">MYSQL</a></li>
									<li><a href="/PostgreSQL/">PostgreSQL</a></li>
                                    <li><a href="/MongoDB/">MongoDB</a></li>
									<li><a href="/PLSQL/">PL/SQL</a></li>
                                 </ul>
                              </li>
							  <li class="has-dropdown">
                                 <a href="">Databases</a>
                                 <ul class="submenu">
                                    <li><a href="/SQL/">SQL</a></li>
                                    <li><a href="/MYSQL/">MYSQL</a></li>
									<li><a href="/PostgreSQL/">PostgreSQL</a></li>
                                    <li><a href="/MongoDB/">MongoDB</a></li>
									<li><a href="/PLSQL/">PL/SQL</a></li>
                                 </ul>
                              </li>
							  
							  
                              
                           </ul>
                        </nav>
                     </div>
                  </div>
                  <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-6 col-6">
                     <div class="tp-header__main-right d-flex justify-content-end align-items-center pl-30">
                        <div class="header-acttion-btns d-flex align-items-center d-none d-md-flex"></a>
                           <a href="/Interviews-Questions/" class="tp-btn br-0">
                              <span>Interviews<i class="fa-solid fa-arrow-right"></i> </span>
                              <div class="transition"></div>
                           </a>
                        </div>
                        <div class="tp-header__hamburger ml-50 d-lg-none">
                           <button class="hamburger-btn offcanvas-open-btn">
                              <span></span>
                              <span></span>
                              <span></span>
                           </button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- header area end -->