-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 31, 2024 at 08:46 AM
-- Server version: 10.5.26-MariaDB
-- PHP Version: 8.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tutorial_master`
--

-- --------------------------------------------------------

--
-- Table structure for table `itio_activity`
--

CREATE TABLE `itio_activity` (
  `id` int(11) NOT NULL,
  `table_id` int(11) DEFAULT NULL,
  `work_title` varchar(500) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `addedby` int(11) DEFAULT NULL,
  `addedon` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_activity`
--

INSERT INTO `itio_activity` (`id`, `table_id`, `work_title`, `ip`, `addedby`, `addedon`) VALUES
(1, 3, 'Add Main Title - Docker ', '60.254.99.11', 1, '2024-11-07 15:58:36'),
(2, 4, 'Add Main Title - kubernetes ', '60.254.99.11', 1, '2024-11-07 15:58:54'),
(3, 5, 'Add Main Title - MongoDB ', '60.254.99.11', 1, '2024-11-07 15:59:08'),
(4, 6, 'Add Main Title - PostgreSql ', '60.254.99.11', 1, '2024-11-07 15:59:24'),
(5, 7, 'Add Main Title - MySql ', '60.254.99.11', 1, '2024-11-07 15:59:43'),
(6, 8, 'Add Main Title - SQL ', '60.254.99.11', 1, '2024-11-07 15:59:54'),
(7, 9, 'Add Main Title - HTML ', '60.254.99.11', 1, '2024-11-07 16:00:36'),
(8, 10, 'Add Main Title - CSS ', '60.254.99.11', 1, '2024-11-07 16:01:00'),
(9, 11, 'Add Main Title - JavaScript ', '60.254.99.11', 1, '2024-11-07 16:01:20'),
(10, 12, 'Add Main Title - Jquery ', '60.254.99.11', 1, '2024-11-07 16:01:35'),
(11, 13, 'Add Main Title - Ajax ', '60.254.99.11', 1, '2024-11-07 16:01:46'),
(12, 14, 'Add Main Title - Bootstrap ', '60.254.99.11', 1, '2024-11-07 16:01:56'),
(13, 15, 'Add Main Title - Git ', '60.254.99.11', 1, '2024-11-07 16:02:08'),
(14, 16, 'Add Main Title - AWS ', '60.254.99.11', 1, '2024-11-07 16:02:20'),
(15, 17, 'Add Main Title - Azure ', '60.254.99.11', 1, '2024-11-07 16:02:29'),
(16, 18, 'Add Main Title - GCP ', '60.254.99.11', 1, '2024-11-07 16:02:39'),
(17, 1, 'Add Sub Menu - vvvvvv ', '116.74.51.200', 1, '2024-11-25 17:38:05'),
(18, 1, 'Update Sub Menu - ppppp ', '116.74.51.200', 1, '2024-11-25 17:38:17'),
(19, 2, 'Add Sub Menu - hhhhhhhhh ', '125.99.7.187', 1, '2024-11-26 03:11:53'),
(20, 3, 'Add Sub Menu - Home ', '49.36.183.30', 1, '2024-11-27 11:20:56'),
(21, 4, 'Add Sub Menu - Overview ', '49.36.183.30', 1, '2024-11-27 11:22:05'),
(22, 5, 'Add Sub Menu - Environment Setup ', '49.36.183.30', 1, '2024-11-27 11:22:09'),
(23, 6, 'Add Sub Menu - Program Structure ', '49.36.183.30', 1, '2024-11-27 11:22:20'),
(24, 7, 'Add Sub Menu - Basic Syntax ', '49.36.183.30', 1, '2024-11-27 11:22:28'),
(25, 8, 'Add Sub Menu - Data Types ', '49.36.183.30', 1, '2024-11-27 11:22:38'),
(26, 9, 'Add Sub Menu - Variables ', '49.36.183.30', 1, '2024-11-27 11:22:48'),
(27, 10, 'Add Sub Menu - Constants ', '49.36.183.30', 1, '2024-11-27 11:22:55'),
(28, 11, 'Add Sub Menu - Operators ', '49.36.183.30', 1, '2024-11-27 11:23:02'),
(29, 12, 'Add Sub Menu - Decision Making ', '49.36.183.30', 1, '2024-11-27 11:23:12'),
(30, 13, 'Add Sub Menu - Loops ', '49.36.183.30', 1, '2024-11-27 11:23:19'),
(31, 14, 'Add Sub Menu - Functions ', '49.36.183.30', 1, '2024-11-27 11:23:27'),
(32, 15, 'Add Sub Menu - Scope Rules ', '49.36.183.30', 1, '2024-11-27 11:23:36'),
(33, 16, 'Add Sub Menu - Strings ', '49.36.183.30', 1, '2024-11-27 11:23:51'),
(34, 17, 'Add Sub Menu - Arrays ', '49.36.183.30', 1, '2024-11-27 11:24:07'),
(35, 18, 'Add Sub Menu - Pointers ', '49.36.183.30', 1, '2024-11-27 11:24:15'),
(36, 19, 'Add Sub Menu - Structures ', '49.36.183.30', 1, '2024-11-27 11:24:24'),
(37, 20, 'Add Sub Menu - Slice ', '49.36.183.30', 1, '2024-11-27 11:24:30'),
(38, 21, 'Add Sub Menu - Range ', '49.36.183.30', 1, '2024-11-27 11:24:37'),
(39, 22, 'Add Sub Menu - Maps ', '49.36.183.30', 1, '2024-11-27 11:24:45'),
(40, 23, 'Add Sub Menu - Recursion ', '49.36.183.30', 1, '2024-11-27 11:24:51'),
(41, 24, 'Add Sub Menu - Type Casting ', '49.36.183.30', 1, '2024-11-27 11:25:04'),
(42, 25, 'Add Sub Menu - Interfaces ', '49.36.183.30', 1, '2024-11-27 11:25:13'),
(43, 26, 'Add Sub Menu - Error Handling ', '49.36.183.30', 1, '2024-11-27 11:25:22'),
(44, 27, 'Add Sub Menu - Go Useful Resources ', '49.36.183.30', 1, '2024-11-27 11:25:32'),
(45, 28, 'Add Sub Menu - Questions and Answers ', '49.36.183.30', 1, '2024-11-27 11:25:40'),
(46, 1, 'Delete - Tutorial_menu', '49.36.183.30', 1, '2024-11-27 11:25:47'),
(47, 2, 'Delete - Tutorial_menu', '49.36.183.30', 1, '2024-11-27 11:25:52'),
(48, 29, 'Add Sub Menu - HOME ', '160.202.37.61', 1, '2024-12-26 04:36:34'),
(49, 30, 'Add Sub Menu - Intro ', '160.202.37.61', 1, '2024-12-26 04:37:21'),
(50, 31, 'Add Sub Menu - RDBMS ', '160.202.37.61', 1, '2024-12-26 04:37:30'),
(51, 32, 'Add Sub Menu - SQL ', '160.202.37.61', 1, '2024-12-26 04:37:41'),
(52, 33, 'Add Sub Menu - SELECT ', '160.202.37.61', 1, '2024-12-26 04:37:46'),
(53, 34, 'Add Sub Menu - WHERE ', '160.202.37.61', 1, '2024-12-26 04:37:52'),
(54, 35, 'Add Sub Menu - AND, OR, NOT ', '160.202.37.61', 1, '2024-12-26 04:38:06'),
(55, 36, 'Add Sub Menu - ORDER BY ', '160.202.37.61', 1, '2024-12-26 04:38:17'),
(56, 37, 'Add Sub Menu - INSERT INTO ', '160.202.37.61', 1, '2024-12-26 04:38:26'),
(57, 38, 'Add Sub Menu - NULL Values ', '160.202.37.61', 1, '2024-12-26 04:38:36'),
(58, 39, 'Add Sub Menu - UPDATE ', '160.202.37.61', 1, '2024-12-26 04:38:46'),
(59, 40, 'Add Sub Menu - DELETE ', '160.202.37.61', 1, '2024-12-26 04:38:57'),
(60, 41, 'Add Sub Menu - LIMIT ', '160.202.37.61', 1, '2024-12-26 04:39:59'),
(61, 42, 'Add Sub Menu - MIN and MAX ', '160.202.37.61', 1, '2024-12-26 04:40:11'),
(62, 43, 'Add Sub Menu - COUNT, AVG, SUM ', '160.202.37.61', 1, '2024-12-26 04:40:22'),
(63, 44, 'Add Sub Menu - LIKE ', '160.202.37.61', 1, '2024-12-26 04:40:31'),
(64, 45, 'Add Sub Menu - Wildcards ', '160.202.37.61', 1, '2024-12-26 04:40:38'),
(65, 46, 'Add Sub Menu - IN ', '160.202.37.61', 1, '2024-12-26 04:40:47'),
(66, 47, 'Add Sub Menu - BETWEEN ', '160.202.37.61', 1, '2024-12-26 04:40:55'),
(67, 48, 'Add Sub Menu - Aliases ', '160.202.37.61', 1, '2024-12-26 04:41:02'),
(68, 49, 'Add Sub Menu - Joins ', '160.202.37.61', 1, '2024-12-26 04:41:11'),
(69, 50, 'Add Sub Menu - INNER JOIN ', '160.202.37.61', 1, '2024-12-26 04:41:20'),
(70, 51, 'Add Sub Menu - LEFT JOIN ', '160.202.37.61', 1, '2024-12-26 04:41:29'),
(71, 52, 'Add Sub Menu - RIGHT JOIN ', '160.202.37.61', 1, '2024-12-26 04:41:37'),
(72, 53, 'Add Sub Menu - CROSS JOIN ', '160.202.37.61', 1, '2024-12-26 04:41:48'),
(73, 54, 'Add Sub Menu - Self Join ', '160.202.37.61', 1, '2024-12-26 04:41:58'),
(74, 55, 'Add Sub Menu - UNION ', '160.202.37.61', 1, '2024-12-26 04:42:13'),
(75, 56, 'Add Sub Menu - GROUP BY ', '160.202.37.61', 1, '2024-12-26 04:42:22'),
(76, 19, 'Add Main Title - TypeScript ', '182.69.179.73', 1, '2024-12-28 13:47:27'),
(77, 19, 'Update Main Title - TypeScript ', '182.69.179.73', 1, '2024-12-28 13:47:37'),
(78, 20, 'Add Main Title - ReactJS ', '182.69.179.73', 1, '2024-12-28 13:47:57'),
(79, 21, 'Add Main Title - NextJS ', '182.69.179.73', 1, '2024-12-28 13:48:05'),
(80, 22, 'Add Main Title - NodeJs ', '182.69.179.73', 1, '2024-12-28 13:48:15'),
(81, 23, 'Add Main Title - Java ', '182.69.179.73', 1, '2024-12-28 13:48:34'),
(82, 24, 'Add Main Title - Python ', '182.69.179.73', 1, '2024-12-28 13:48:43'),
(83, 25, 'Add Main Title - Kotlin ', '182.69.179.73', 1, '2024-12-28 13:48:56'),
(84, 26, 'Add Main Title - MariaDB ', '182.69.179.73', 1, '2024-12-28 14:20:35'),
(85, 57, 'Add Sub Menu - HAVING ', '182.69.179.73', 1, '2024-12-29 10:10:16'),
(86, 58, 'Add Sub Menu - EXISTS ', '182.69.179.73', 1, '2024-12-29 10:11:02'),
(87, 59, 'Add Sub Menu - ANY, ALL ', '182.69.179.73', 1, '2024-12-29 10:11:18'),
(88, 60, 'Add Sub Menu - INSERT SELECT ', '182.69.179.73', 1, '2024-12-29 10:12:23'),
(89, 61, 'Add Sub Menu - CASE ', '182.69.179.73', 1, '2024-12-29 10:12:39'),
(90, 62, 'Add Sub Menu - Null Functions ', '182.69.179.73', 1, '2024-12-29 10:12:54'),
(91, 63, 'Add Sub Menu - Comments ', '182.69.179.73', 1, '2024-12-29 10:13:16'),
(92, 64, 'Add Sub Menu - Operators ', '182.69.179.73', 1, '2024-12-29 10:13:32'),
(93, 65, 'Add Sub Menu - Home ', '160.202.37.15', 1, '2024-12-30 07:27:24'),
(94, 66, 'Add Sub Menu - Overview ', '160.202.37.15', 1, '2024-12-30 07:27:27'),
(95, 67, 'Add Sub Menu - Environment Setup ', '160.202.37.15', 1, '2024-12-30 07:27:36'),
(96, 68, 'Add Sub Menu - Architecture ', '160.202.37.15', 1, '2024-12-30 07:27:48'),
(97, 69, 'Add Sub Menu - Basic Syntax ', '160.202.37.15', 1, '2024-12-30 07:27:57'),
(98, 70, 'Add Sub Menu - Comments ', '160.202.37.15', 1, '2024-12-30 07:28:11'),
(99, 71, 'Add Sub Menu - Keywords ', '160.202.37.15', 1, '2024-12-30 07:28:34'),
(100, 72, 'Add Sub Menu - Variables ', '160.202.37.15', 1, '2024-12-30 07:28:45'),
(101, 73, 'Add Sub Menu - Data Types ', '160.202.37.15', 1, '2024-12-30 07:28:55'),
(102, 74, 'Add Sub Menu - Operators ', '160.202.37.15', 1, '2024-12-30 07:29:53'),
(103, 75, 'Add Sub Menu - Booleans ', '160.202.37.15', 1, '2024-12-30 07:30:01'),
(104, 76, 'Add Sub Menu - Strings ', '160.202.37.15', 1, '2024-12-30 07:30:13'),
(105, 77, 'Add Sub Menu - Arrays ', '160.202.37.15', 1, '2024-12-30 07:30:23'),
(106, 78, 'Add Sub Menu - Ranges ', '160.202.37.15', 1, '2024-12-30 07:30:32'),
(107, 79, 'Add Sub Menu - Functions ', '160.202.37.15', 1, '2024-12-30 07:30:41'),
(108, 80, 'Add Sub Menu - Control Flow ', '160.202.37.15', 1, '2024-12-30 07:30:50'),
(109, 81, 'Add Sub Menu - if Else Expression ', '160.202.37.15', 1, '2024-12-30 07:30:59'),
(110, 82, 'Add Sub Menu - When Expression ', '160.202.37.15', 1, '2024-12-30 07:31:08'),
(111, 83, 'Add Sub Menu - For Loop ', '160.202.37.15', 1, '2024-12-30 07:31:17'),
(112, 84, 'Add Sub Menu - While Loop ', '160.202.37.15', 1, '2024-12-30 07:31:32'),
(113, 85, 'Add Sub Menu - Break and Continue ', '160.202.37.15', 1, '2024-12-30 07:32:07'),
(114, 86, 'Add Sub Menu - Collections ', '160.202.37.15', 1, '2024-12-30 07:32:19'),
(115, 87, 'Add Sub Menu - Lists ', '160.202.37.15', 1, '2024-12-30 07:32:31'),
(116, 88, 'Add Sub Menu - Sets ', '160.202.37.15', 1, '2024-12-30 07:32:40'),
(117, 89, 'Add Sub Menu - Maps ', '160.202.37.15', 1, '2024-12-30 07:32:50'),
(118, 90, 'Add Sub Menu - Class and Objects ', '160.202.37.15', 1, '2024-12-30 07:33:02'),
(119, 91, 'Add Sub Menu - Constructors ', '160.202.37.15', 1, '2024-12-30 07:33:11'),
(120, 92, 'Add Sub Menu - Inheritance ', '160.202.37.15', 1, '2024-12-30 07:33:26'),
(121, 93, 'Add Sub Menu - Abstract Classes ', '160.202.37.15', 1, '2024-12-30 07:33:35'),
(122, 94, 'Add Sub Menu - Interface ', '160.202.37.15', 1, '2024-12-30 07:33:49'),
(123, 95, 'Add Sub Menu - Visibility Control ', '160.202.37.15', 1, '2024-12-30 07:34:00'),
(124, 96, 'Add Sub Menu - Extension ', '160.202.37.15', 1, '2024-12-30 07:34:31'),
(125, 97, 'Add Sub Menu - Data Classes ', '160.202.37.15', 1, '2024-12-30 07:34:42'),
(126, 98, 'Add Sub Menu - Sealed Class ', '160.202.37.15', 1, '2024-12-30 07:34:50'),
(127, 99, 'Add Sub Menu - Generics ', '160.202.37.15', 1, '2024-12-30 07:34:59'),
(128, 100, 'Add Sub Menu - Delegation ', '160.202.37.15', 1, '2024-12-30 07:35:11'),
(129, 101, 'Add Sub Menu - Destructuring Declarations ', '160.202.37.15', 1, '2024-12-30 07:35:27'),
(130, 102, 'Add Sub Menu - Exception Handling ', '160.202.37.15', 1, '2024-12-30 07:35:38'),
(131, 103, 'Add Sub Menu - Features ', '160.202.37.15', 1, '2024-12-30 07:39:40'),
(132, 104, 'Add Sub Menu - Docker architecture ', '160.202.37.15', 1, '2024-12-30 07:39:52'),
(133, 105, 'Add Sub Menu - Installation on Ubuntu ', '160.202.37.15', 1, '2024-12-30 07:40:01'),
(134, 106, 'Add Sub Menu - Installation on Windows ', '160.202.37.15', 1, '2024-12-30 07:40:11'),
(135, 107, 'Add Sub Menu - Image & Container ', '160.202.37.15', 1, '2024-12-30 07:40:20'),
(136, 108, 'Add Sub Menu - Dockerfile ', '160.202.37.15', 1, '2024-12-30 07:40:29'),
(137, 109, 'Add Sub Menu - Java Example ', '160.202.37.15', 1, '2024-12-30 07:40:44'),
(138, 110, 'Add Sub Menu - Php Example ', '160.202.37.15', 1, '2024-12-30 07:40:56'),
(139, 111, 'Add Sub Menu - Python Example ', '160.202.37.15', 1, '2024-12-30 07:41:06'),
(140, 112, 'Add Sub Menu - Scala Example ', '160.202.37.15', 1, '2024-12-30 07:41:16'),
(141, 113, 'Add Sub Menu - Perl Example ', '160.202.37.15', 1, '2024-12-30 07:41:51'),
(142, 114, 'Add Sub Menu - Ruby Example ', '160.202.37.15', 1, '2024-12-30 07:42:01'),
(143, 115, 'Add Sub Menu - Swift Example ', '160.202.37.15', 1, '2024-12-30 07:42:13'),
(144, 116, 'Add Sub Menu - Ubuntu Example ', '160.202.37.15', 1, '2024-12-30 07:42:42'),
(145, 117, 'Add Sub Menu - Push Repository ', '160.202.37.15', 1, '2024-12-30 07:42:54'),
(146, 118, 'Add Sub Menu - Useful Commands ', '160.202.37.15', 1, '2024-12-30 07:43:05'),
(147, 119, 'Add Sub Menu - Cloud ', '160.202.37.15', 1, '2024-12-30 07:43:14'),
(148, 120, 'Add Sub Menu - Compose ', '160.202.37.15', 1, '2024-12-30 07:43:22'),
(149, 121, 'Add Sub Menu - Storage Driver ', '160.202.37.15', 1, '2024-12-30 07:43:32'),
(150, 122, 'Add Sub Menu - vs Kubernetes ', '160.202.37.15', 1, '2024-12-30 07:43:39'),
(151, 122, 'Update Sub Menu - Docker vs Kubernetes ', '160.202.37.15', 1, '2024-12-30 07:44:13'),
(152, 123, 'Add Sub Menu - HOME ', '160.202.37.15', 1, '2024-12-30 12:10:24'),
(153, 124, 'Add Sub Menu - Tutorial ', '160.202.37.15', 1, '2024-12-30 12:10:26'),
(154, 125, 'Add Sub Menu - Get Started ', '160.202.37.15', 1, '2024-12-30 12:10:34'),
(155, 126, 'Add Sub Menu - Query API ', '160.202.37.15', 1, '2024-12-30 12:10:43'),
(156, 127, 'Add Sub Menu - Create DB ', '160.202.37.15', 1, '2024-12-30 12:10:55'),
(157, 128, 'Add Sub Menu - Collection ', '160.202.37.15', 1, '2024-12-30 12:11:13'),
(158, 129, 'Add Sub Menu - Insert ', '160.202.37.15', 1, '2024-12-30 12:11:33'),
(159, 130, 'Add Sub Menu - Find ', '160.202.37.15', 1, '2024-12-30 12:11:41'),
(160, 131, 'Add Sub Menu - Update ', '160.202.37.15', 1, '2024-12-30 12:11:51'),
(161, 132, 'Add Sub Menu - Delete ', '160.202.37.15', 1, '2024-12-30 12:12:00'),
(162, 133, 'Add Sub Menu - Query Operators ', '160.202.37.15', 1, '2024-12-30 12:12:14'),
(163, 134, 'Add Sub Menu - Update Operators ', '160.202.37.15', 1, '2024-12-30 12:16:06'),
(164, 135, 'Add Sub Menu - Aggregations ', '160.202.37.15', 1, '2024-12-30 12:16:16'),
(165, 136, 'Add Sub Menu - Indexing OR Search ', '160.202.37.15', 1, '2024-12-30 12:16:34'),
(166, 137, 'Add Sub Menu - Validation ', '160.202.37.15', 1, '2024-12-30 12:16:41'),
(167, 138, 'Add Sub Menu - Data API ', '160.202.37.15', 1, '2024-12-30 12:16:49'),
(168, 139, 'Add Sub Menu - Drivers ', '160.202.37.15', 1, '2024-12-30 12:16:58'),
(169, 140, 'Add Sub Menu - Node.js Driver ', '160.202.37.15', 1, '2024-12-30 12:17:08'),
(170, 141, 'Add Sub Menu - Charts ', '160.202.37.15', 1, '2024-12-30 12:17:16'),
(171, 142, 'Add Sub Menu - Home ', '160.202.37.15', 1, '2024-12-30 12:20:01'),
(172, 143, 'Add Sub Menu - Intro ', '160.202.37.15', 1, '2024-12-30 12:20:08'),
(173, 144, 'Add Sub Menu - Install ', '160.202.37.15', 1, '2024-12-30 12:20:14'),
(174, 145, 'Add Sub Menu - Get Started ', '160.202.37.15', 1, '2024-12-30 12:20:24'),
(175, 146, 'Add Sub Menu - pgAdmin 4 ', '160.202.37.15', 1, '2024-12-30 12:20:33'),
(176, 147, 'Add Sub Menu - CREATE TABLE ', '160.202.37.15', 1, '2024-12-30 12:20:42'),
(177, 148, 'Add Sub Menu - INSERT INTO ', '160.202.37.15', 1, '2024-12-30 12:20:51'),
(178, 149, 'Add Sub Menu - Fetch Data ', '160.202.37.15', 1, '2024-12-30 12:21:00'),
(179, 150, 'Add Sub Menu - ADD COLUMN ', '160.202.37.15', 1, '2024-12-30 12:21:08'),
(180, 151, 'Add Sub Menu - UPDATE ', '160.202.37.15', 1, '2024-12-30 12:21:15'),
(181, 152, 'Add Sub Menu - ALTER COLUMN ', '160.202.37.15', 1, '2024-12-30 12:21:53'),
(182, 153, 'Add Sub Menu - DROP COLUMN ', '160.202.37.15', 1, '2024-12-30 12:22:00'),
(183, 154, 'Add Sub Menu - DELETE ', '160.202.37.15', 1, '2024-12-30 12:22:08'),
(184, 155, 'Add Sub Menu - DROP TABLE ', '160.202.37.15', 1, '2024-12-30 12:22:17'),
(185, 156, 'Add Sub Menu - Syntax ', '160.202.37.15', 1, '2024-12-30 12:22:32'),
(186, 157, 'Add Sub Menu - Operators ', '160.202.37.15', 1, '2024-12-30 12:22:40'),
(187, 158, 'Add Sub Menu - SELECT ', '160.202.37.15', 1, '2024-12-30 12:22:50'),
(188, 159, 'Add Sub Menu - SELECT DISTINCT ', '160.202.37.15', 1, '2024-12-30 12:23:02'),
(189, 160, 'Add Sub Menu - WHERE ', '160.202.37.15', 1, '2024-12-30 12:23:14'),
(190, 161, 'Add Sub Menu - ORDER BY ', '160.202.37.15', 1, '2024-12-30 12:23:23'),
(191, 162, 'Add Sub Menu - LIMIT ', '160.202.37.15', 1, '2024-12-30 12:24:18'),
(192, 163, 'Add Sub Menu - MIN and MAX ', '160.202.37.15', 1, '2024-12-30 12:24:25'),
(193, 164, 'Add Sub Menu - COUNT ', '160.202.37.15', 1, '2024-12-30 12:24:33'),
(194, 165, 'Add Sub Menu - SUM ', '160.202.37.15', 1, '2024-12-30 12:24:39'),
(195, 166, 'Add Sub Menu - AVG ', '160.202.37.15', 1, '2024-12-30 12:24:44'),
(196, 167, 'Add Sub Menu - LIKE ', '160.202.37.15', 1, '2024-12-30 12:24:51'),
(197, 168, 'Add Sub Menu - IN ', '160.202.37.15', 1, '2024-12-30 12:24:57'),
(198, 169, 'Add Sub Menu - BETWEEN ', '160.202.37.15', 1, '2024-12-30 12:25:03'),
(199, 170, 'Add Sub Menu - AS ', '160.202.37.15', 1, '2024-12-30 12:25:08'),
(200, 171, 'Add Sub Menu - Joins ', '160.202.37.15', 1, '2024-12-30 12:25:14'),
(201, 172, 'Add Sub Menu - INNER JOIN ', '160.202.37.15', 1, '2024-12-30 12:26:09'),
(202, 173, 'Add Sub Menu - LEFT JOIN ', '160.202.37.15', 1, '2024-12-30 12:26:20'),
(203, 174, 'Add Sub Menu - RIGHT JOIN ', '160.202.37.15', 1, '2024-12-30 12:26:30'),
(204, 175, 'Add Sub Menu - FULL JOIN ', '160.202.37.15', 1, '2024-12-30 12:26:42'),
(205, 176, 'Add Sub Menu - CROSS JOIN ', '160.202.37.15', 1, '2024-12-30 12:26:51'),
(206, 177, 'Add Sub Menu - UNION ', '160.202.37.15', 1, '2024-12-30 12:26:58'),
(207, 178, 'Add Sub Menu - GROUP BY ', '160.202.37.15', 1, '2024-12-30 12:31:08'),
(208, 179, 'Add Sub Menu - HAVING ', '160.202.37.15', 1, '2024-12-30 12:31:11'),
(209, 180, 'Add Sub Menu - EXISTS ', '160.202.37.15', 1, '2024-12-30 12:31:20'),
(210, 181, 'Add Sub Menu - ANY ', '160.202.37.15', 1, '2024-12-30 12:31:25'),
(211, 182, 'Add Sub Menu - ALL ', '160.202.37.15', 1, '2024-12-30 12:31:30'),
(212, 183, 'Add Sub Menu - CASE ', '160.202.37.15', 1, '2024-12-30 12:31:36');

-- --------------------------------------------------------

--
-- Table structure for table `itio_admin`
--

CREATE TABLE `itio_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_user` varchar(50) NOT NULL,
  `admin_pass` varchar(100) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `admin_mobile` varchar(12) NOT NULL,
  `admin_email` varchar(100) DEFAULT NULL,
  `admin_address` varchar(200) DEFAULT NULL,
  `admin_designation` varchar(100) DEFAULT NULL,
  `admin_profile_pic` varchar(200) DEFAULT NULL,
  `admin_roles` text DEFAULT NULL,
  `admin_type` varchar(10) NOT NULL DEFAULT '0',
  `admin_status` int(1) NOT NULL DEFAULT 1,
  `admin_addedby` int(11) DEFAULT NULL,
  `admin_addedon` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `itio_admin`
--

INSERT INTO `itio_admin` (`admin_id`, `admin_user`, `admin_pass`, `admin_name`, `admin_mobile`, `admin_email`, `admin_address`, `admin_designation`, `admin_profile_pic`, `admin_roles`, `admin_type`, `admin_status`, `admin_addedby`, `admin_addedon`) VALUES
(1, 'vikash', 'e20383708e67d5f9bf1c03944bf191d1d5bee069e05d9dff453cbfdbcb37de02', 'Vikash Kumar Gupta', '955553874066', 'vikash4eindia@gmail.com', 'India 110088 55 T6', 'Web Developer22 8888', NULL, '{\"epayment\":\"1\",\"send-payment\":\"1\",\"transactions\":\"1\",\"tutorials\":\"1\",\"add-tutorial\":\"1\",\"chat\":\"1\",\"tutorial-menu-manager\":\"1\",\"tutorial-title-manager\":\"1\",\"tutorials-list-manager\":\"1\",\"menu-&-submenu\":\"1\",\"menu-manager\":\"1\",\"menu-order-manager\":\"1\",\"submenu-manager\":\"1\",\"users-&-roles\":\"1\",\"add-user\":\"1\",\"manage-user\":\"1\",\"user-logged-history\":\"1\"}', '11', 1, 1, '2024-11-07 15:48:39');

-- --------------------------------------------------------

--
-- Table structure for table `itio_login_master`
--

CREATE TABLE `itio_login_master` (
  `id` int(11) NOT NULL,
  `user_id` int(5) NOT NULL,
  `log_ip` varchar(20) NOT NULL,
  `log_on` datetime NOT NULL,
  `log_out` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `itio_login_master`
--

INSERT INTO `itio_login_master` (`id`, `user_id`, `log_ip`, `log_on`, `log_out`) VALUES
(1, 1, '60.254.99.11', '2024-11-07 08:38:16', '2024-11-07 08:38:45'),
(2, 1, '60.254.99.11', '2024-11-07 08:39:03', NULL),
(3, 1, '60.254.99.11', '2024-11-07 21:17:44', '2024-11-07 21:23:53'),
(4, 1, '60.254.99.11', '2024-11-07 21:25:39', NULL),
(5, 1, '160.202.37.33', '2024-11-12 17:46:03', '2024-11-12 17:46:53'),
(6, 1, '160.202.37.41', '2024-11-25 12:04:40', '2024-11-25 12:07:26'),
(7, 1, '160.202.37.41', '2024-11-25 12:26:03', '2024-11-25 12:31:13'),
(8, 1, '116.74.51.200', '2024-11-25 22:40:56', '2024-11-25 22:44:05'),
(9, 1, '116.74.51.200', '2024-11-25 22:44:13', NULL),
(10, 1, '125.99.7.187', '2024-11-26 08:41:21', NULL),
(11, 1, '49.36.183.30', '2024-11-27 16:49:52', '2024-11-27 17:14:20'),
(12, 1, '116.75.235.81', '2024-11-29 08:51:17', NULL),
(13, 1, '182.69.129.151', '2024-12-22 20:20:54', NULL),
(14, 1, '160.202.37.61', '2024-12-26 09:59:44', NULL),
(15, 1, '182.69.176.235', '2024-12-26 21:00:51', NULL),
(16, 1, '182.69.179.73', '2024-12-27 10:20:42', NULL),
(17, 1, '182.69.179.73', '2024-12-28 10:15:22', NULL),
(18, 1, '182.69.179.73', '2024-12-28 12:15:52', NULL),
(19, 1, '182.69.179.73', '2024-12-28 18:26:02', NULL),
(20, 1, '182.69.179.73', '2024-12-28 18:26:02', NULL),
(21, 1, '182.69.179.73', '2024-12-29 15:33:38', NULL),
(22, 1, '160.202.37.15', '2024-12-30 12:55:56', '2024-12-30 13:17:49'),
(23, 1, '160.202.37.15', '2024-12-30 17:39:28', NULL),
(24, 1, '160.202.37.15', '2024-12-30 18:00:24', '2024-12-30 18:05:26');

-- --------------------------------------------------------

--
-- Table structure for table `itio_master_trans_table`
--

CREATE TABLE `itio_master_trans_table` (
  `transaction_id` int(11) NOT NULL,
  `member_id` int(20) NOT NULL,
  `transaction_type` varchar(25) DEFAULT NULL,
  `transaction_for` varchar(25) DEFAULT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_currency` varchar(20) DEFAULT NULL,
  `transaction_amount` decimal(10,2) DEFAULT NULL,
  `converted_transaction_currency` varchar(20) DEFAULT NULL,
  `converted_transaction_amount` decimal(10,2) DEFAULT NULL,
  `transaction_bank_name` varchar(255) DEFAULT NULL,
  `transaction_ac_no` varchar(50) DEFAULT NULL,
  `transaction_swift_code` varchar(20) DEFAULT NULL,
  `transaction_bank_address` varchar(255) DEFAULT NULL,
  `transaction_bank_id` int(11) DEFAULT NULL,
  `transaction_purpose` varchar(255) DEFAULT NULL,
  `usr_name` varchar(50) DEFAULT NULL,
  `usr_address` varchar(255) DEFAULT NULL,
  `usr_descricption` varchar(255) DEFAULT NULL,
  `admin_transaction_id` varchar(50) DEFAULT NULL,
  `admin_transaction_desc` text DEFAULT NULL,
  `admin_approval_status` varchar(255) DEFAULT NULL,
  `admin_transaction_date` datetime DEFAULT NULL,
  `transaction_fee_linked_account` varchar(50) DEFAULT NULL,
  `transaction_status` varchar(55) NOT NULL DEFAULT 'Process',
  `available_balance` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `itio_menu`
--

CREATE TABLE `itio_menu` (
  `menu_id` int(11) NOT NULL,
  `menu_title` varchar(200) NOT NULL,
  `menu_icon` varchar(100) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `priority` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_menu`
--

INSERT INTO `itio_menu` (`menu_id`, `menu_title`, `menu_icon`, `status`, `priority`) VALUES
(6, 'Menu & Submenu', 'fa-solid fa-bars', 1, 2),
(8, 'Users & Roles', 'fa-solid fa-user-group', 1, 5),
(11, 'epayment', 'fa-brands fa-amazon-pay', 1, 0),
(12, 'Tutorials', 'fa-solid fa-book', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `itio_submenu`
--

CREATE TABLE `itio_submenu` (
  `submenu_id` int(11) NOT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `submenu_title` varchar(200) DEFAULT NULL,
  `status` int(1) DEFAULT 1,
  `addedby` int(11) NOT NULL,
  `addedon` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_submenu`
--

INSERT INTO `itio_submenu` (`submenu_id`, `menu_id`, `submenu_title`, `status`, `addedby`, `addedon`) VALUES
(13, 6, 'Submenu Manager', 1, 0, '2023-09-30 07:05:47'),
(14, 6, 'Menu Manager', 1, 0, '2023-09-30 07:05:59'),
(15, 8, 'Add User', 1, 0, '2023-09-30 07:06:39'),
(16, 8, 'Manage User', 1, 0, '2023-09-30 07:07:04'),
(17, 8, 'Manage Roles', 2, 0, '2023-10-03 08:55:22'),
(18, 6, 'Menu Order Manager', 1, 0, '2023-10-03 09:01:34'),
(51, 8, 'User Logged History', 1, 0, '2023-10-25 06:13:38'),
(53, 11, 'Send Payment', 1, 0, '2023-11-15 04:28:56'),
(54, 11, 'Transactions', 1, 0, '2023-11-15 04:29:09'),
(55, 12, 'Tutorial Menu Manager', 1, 0, '2024-11-05 04:50:19'),
(56, 12, 'Tutorial Title Manager', 1, 0, '2024-11-05 04:52:36'),
(57, 12, 'Chat', 2, 0, '2024-11-05 05:06:14'),
(58, 12, 'Add Tutorial', 1, 0, '2024-11-05 04:50:58'),
(59, 12, 'Tutorials List Manager', 1, 0, '2024-11-05 04:52:00');

-- --------------------------------------------------------

--
-- Table structure for table `itio_tutorial_master`
--

CREATE TABLE `itio_tutorial_master` (
  `tutorial_id` int(11) NOT NULL,
  `tutorial_menu` int(11) DEFAULT NULL,
  `tutorial_submenu` int(11) DEFAULT NULL,
  `tutorial_title` varchar(255) DEFAULT NULL,
  `tutorial_desc1` text DEFAULT NULL,
  `tutorial_desc2` text DEFAULT NULL,
  `tutorial_desc3` text DEFAULT NULL,
  `tutorial_desc4` text DEFAULT NULL,
  `tutorial_desc5` text DEFAULT NULL,
  `tutorial_image` varchar(255) DEFAULT NULL,
  `tutorial_status` int(1) NOT NULL DEFAULT 1,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_tutorial_master`
--

INSERT INTO `itio_tutorial_master` (`tutorial_id`, `tutorial_menu`, `tutorial_submenu`, `tutorial_title`, `tutorial_desc1`, `tutorial_desc2`, `tutorial_desc3`, `tutorial_desc4`, `tutorial_desc5`, `tutorial_image`, `tutorial_status`, `timestamp`) VALUES
(6, 1, 17, 'Arrays', '<p>In Go, arrays are fixed-size collections of elements of the same type. They provide a way to store multiple values in a single variable. Below are the key concepts and usage examples of arrays in Go:</p><hr><h3><b>Syntax</b></h3><pre class=\"!overflow-visible\"><p class=\"contain-inline-size rounded-md border-[0.5px] border-token-border-medium relative bg-token-sidebar-surface-primary dark:bg-gray-950\"><p class=\"flex items-center text-token-text-secondary px-4 py-2 text-xs font-sans justify-between rounded-t-md h-9 bg-token-sidebar-surface-primary dark:bg-token-main-surface-secondary select-none\"><code class=\"!whitespace-pre hljs language-go\"><span class=\"hljs-keyword\">var</span> arrayName [size]Type</code></p></p></pre><ul><li><code>size</code> is the number of elements in the array.</li><li><code>Type</code> specifies the type of elements in the array.</li></ul>', '<h3><b>Examples</b></h3><h4><b>1. Declaring and Initializing an Array</b></h4><pre class=\"!overflow-visible\"><span class=\"hljs-comment\">var numbers [5]int // An array of 5 integers with default value 0<br>fmt.Println(numbers) // Output: [0 0 0 0 0]<br><br>// Declaring and initializing in one line<br>days := [7]string{\"Monday\", \"Tuesday\", \"Wednesday\", \"Thursday\", \"Friday\", \"Saturday\", \"Sunday\"}<br>fmt.Println(days) // Output: [Monday Tuesday Wednesday Thursday Friday Saturday Sunday]<br><br>// Letting Go infer the size<br>colors := [...]string{\"Red\", \"Green\", \"Blue\"}<br>fmt.Println(colors) // Output: [Red Green Blue]<br></span></pre><hr><h4><b>2. Accessing and Modifying Elements</b></h4><pre class=\"!overflow-visible\"><p class=\"contain-inline-size rounded-md border-[0.5px] border-token-border-medium relative bg-token-sidebar-surface-primary dark:bg-gray-950\"></p>var arr [3]int<br>arr[0] = 10<br>arr[1] = 20<br>arr[2] = 30<br>fmt.Println(arr) // Output: [10 20 30]<br><br>fmt.Println(arr[1]) // Output: 20<p></p></pre><hr><h4><b>3. Iterating Over an Array</b></h4><p>Using <code>for</code> loop:</p><pre class=\"!overflow-visible\"><p class=\"contain-inline-size rounded-md border-[0.5px] border-token-border-medium relative bg-token-sidebar-surface-primary dark:bg-gray-950\"></p><p class=\"overflow-y-auto p-4\" dir=\"ltr\">numbers := [5]int{1, 2, 3, 4, 5}<br>for i := 0; i < len(numbers); i++ {<br>    fmt.Println(numbers[i])<br>}</p><p></p></pre><p>Using <code>for range</code>:</p><pre class=\"!overflow-visible\">for index, value := range numbers {<br>    fmt.Printf(\"Index: %d, Value: %d\\n\", index, value)<br>}<br></pre><hr><h4><b>4. Multi-Dimensional Arrays</b></h4><pre class=\"!overflow-visible\">var matrix [2][3]int<br>matrix[0][0] = 1<br>matrix[0][1] = 2<br>matrix[0][2] = 3<br>matrix[1][0] = 4<br>matrix[1][1] = 5<br>matrix[1][2] = 6<br>fmt.Println(matrix)<br>// Output: [[1 2 3] [4 5 6]]<br></pre><hr><h4><b>5. Passing Arrays to Functions</b></h4><p>Arrays in Go are passed by value (a copy of the array is passed).</p><pre class=\"!overflow-visible\">func modifyArray(arr [3]int) {<br>    arr[0] = 100<br>}<br><br>func main() {<br>    nums := [3]int{1, 2, 3}<br>    modifyArray(nums)<br>    fmt.Println(nums) // Output: [1 2 3]<br>}<br></pre>', '<p class=\"flex max-w-full flex-col flex-grow\"></p><p data-message-author-role=\"assistant\" data-message-id=\"961388e0-4d73-4e12-ba4f-b69d03650f0f\" dir=\"auto\" class=\"min-h-8 text-message flex w-full flex-col items-end gap-2 whitespace-normal break-words text-start [.text-message+&]:mt-5\" data-message-model-slug=\"gpt-4o\"></p><p class=\"flex w-full flex-col gap-1 empty:hidden first:pt-[3px]\"></p><p class=\"markdown prose w-full break-words dark:prose-invert light\"></p><p>If you want to modify the original array, pass a pointer to it:</p><pre class=\"!overflow-visible\"><p class=\"contain-inline-size rounded-md border-[0.5px] border-token-border-medium relative bg-token-sidebar-surface-primary dark:bg-gray-950\"></p><p class=\"overflow-y-auto p-4\" dir=\"ltr\">func modifyArray(arr *[3]int) {<br>    arr[0] = 100<br>}<br><br>func main() {<br>    nums := [3]int{1, 2, 3}<br>    modifyArray(&nums)<br>    fmt.Println(nums) // Output: [100 2 3]<br>}<br></p><p></p><p></p><p></p></pre><hr><h4><b>6. Comparing Arrays</b></h4><p>Arrays can be compared using the <code>==</code> operator if they are of the same type and size.</p><p><b>a := [3]int{1, 2, 3} Â <br>b := [3]int{1, 2, 3} Â <br>c := [3]int{4, 5, 6}Â Â  Â <br>fmt.Println(a == b) // Output: true Â <br>fmt.Println(a == c) // Output: false</b><br></p><hr><h3><b>Key Points</b></h3><ul><li>Arrays in Go have a fixed size and cannot be resized.</li><li>For dynamic sizes, use <b>slices</b>, which are more flexible and commonly used.</li><li>Arrays are value types, meaning modifications to an array in a function do not affect the original unless passed by reference.</li></ul><p>Let me know if you want more details about <b>slices</b> or specific array operations!</p><p></p><p></p><p></p><br>', '', '', '210986_arrays.webp', 1, '2024-12-26 22:38:00'),
(7, 1, 3, 'About Golang', '<p>Go (often referred to as <b>Golang</b>) is a statically typed, compiled programming language designed at Google by <b>Robert Griesemer</b>, <b>Rob Pike</b>, and <b>Ken Thompson</b>. It was introduced in 2009 and is known for its simplicity, efficiency, and support for modern programming paradigms like concurrency and cloud computing.</p><hr><h3><b>Key Features of Go</b></h3><ol><li><p><b>Simplicity and Clean Syntax</b>:</p><ul><li>Go prioritizes readability and simplicity.</li><li>It avoids complex features like inheritance, generics (introduced in Go 1.18 but minimal), and implicit type conversions.</li></ul></li><li><p><b>Concurrency</b>:</p><ul><li>Built-in support for concurrency using <b>goroutines</b> and <b>channels</b>.</li><li>Efficient handling of thousands of goroutines with minimal resource consumption.</li></ul></li><li><p><b>Performance</b>:</p><ul><li>Being a compiled language, it offers performance close to C/C++.</li><li>Efficient memory management with garbage collection.</li></ul></li><li><p><b>Cross-Platform Compilation</b>:</p><ul><li>Compile code for multiple operating systems and architectures using the <code>GOOS</code> and <code>GOARCH</code> environment variables.</li></ul></li><li><p><b>Strong Standard Library</b>:</p><ul><li>Provides extensive libraries for tasks like networking, web servers, and file handling.</li></ul></li><li><p><b>Tooling and Productivity</b>:</p><ul><li>Built-in tools for testing (<code>go test</code>), benchmarking, formatting (<code>go fmt</code>), and dependency management.</li></ul></li><li><p><b>Statically Typed</b>:</p><ul><li>Catch type-related errors at compile time, enhancing code reliability.</li></ul></li><li><p><b>Open Source</b>:</p><ul><li>Actively developed and maintained with contributions from developers worldwide.</li></ul></li></ol><hr><h3><b>Hello, World! in Go</b></h3><pre class=\"!overflow-visible\"><p class=\"contain-inline-size rounded-md border-[0.5px] border-token-border-medium relative bg-token-sidebar-surface-primary dark:bg-gray-950\"><p class=\"overflow-y-auto p-4\" dir=\"ltr\"><code class=\"!whitespace-pre hljs language-go\">package main<br><br>import \"fmt\"<br><br>func main() {<br>    fmt.Println(\"Hello, World!\")<br>}</code></p></p></pre><hr><h3><b>Applications of Go</b></h3><ol><li><p><b>Web Development</b>:</p><ul><li>Frameworks like <b>Fiber</b>, <b>Gin</b>, and <b>Echo</b> make web development seamless.</li></ul></li><li><p><b>Cloud and DevOps</b>:</p><ul><li>Ideal for cloud-native applications and tools like <b>Docker</b> and <b>Kubernetes</b> (written in Go).</li></ul></li><li><p><b>Networking and Microservices</b>:</p><ul><li>Supports high-performance networking applications and microservices.</li></ul></li><li><p><b>Data Processing</b>:</p><ul><li>Handles concurrent and distributed data processing efficiently.</li></ul></li><li><p><b>Command-Line Tools</b>:</p><ul><li>Many CLI tools are developed using Go because of its simplicity and cross-platform support.</li></ul></li></ol><hr><h3><b>Advantages of Go</b></h3><ul><li><b>Fast Compilation</b>: Quick compile times, even for large projects.</li><li><b>Concurrency</b>: Native support for concurrent programming.</li><li><b>Easy to Learn</b>: Simple and beginner-friendly syntax.</li><li><b>Scalability</b>: Perfect for building scalable, distributed systems.</li></ul><hr><h3><b>Disadvantages of Go</b></h3><ul><li><b>Minimalistic</b>: Lack of advanced features like templates and complex generics (partially addressed in Go 1.18).</li><li><b>Verbose</b>: No implicit coding shortcuts; some developers find it overly explicit.</li><li><b>Dependency Management</b>: Earlier issues with dependency management (addressed by <code>go modules</code>).</li></ul><hr><h3><b>Why Learn Go?</b></h3><ul><li>It is a modern, versatile language perfect for high-performance, scalable applications.</li><li>Adopted by tech giants like Google, Uber, Netflix, and Dropbox.</li><li>Go\'s community and ecosystem are growing rapidly.</li></ul><p>If you\'d like to dive deeper into any specific aspect of Go (e.g., concurrency, packages, or web frameworks), let me know!</p>', '', '', '', '', '567439_arrays.webp', 1, '2024-12-28 13:33:09'),
(8, 1, 8, 'Data Type', '<p>GoLang provides a wide variety of data types, which can be categorized into four major groups: <b>basic types</b>, <b>aggregate types</b>, <b>reference types</b>, and <b>interface types</b>.</p><hr><h3><b>1. Basic Data Types</b></h3><p>These are the fundamental data types in Go.</p><h4><b>Numeric Types</b></h4><ol>  <li>    <p><b>Integer Types</b>:</p>    <ul>      <li><b>Signed Integers</b>:          <ul>            <li>int (platform-dependent, typically 32 or 64 bits)</li>            <li>int8, int16, int32, int64</li>          </ul>      </li>      <li><b>Unsigned Integers</b>:          <ul>            <li>uint (platform-dependent)</li>            <li>uint8, uint16, uint32, uint64</li>            <li>byte (alias for uint8)</li>          </ul>      </li>    </ul>  </li>  <li>    <p><b>Floating-Point Numbers</b>:</p>    <ul>      <li>float32, float64</li>    </ul>  </li>  <li>    <p><b>Complex Numbers</b>:</p>    <ul>      <li>complex64 (real and imaginary parts as float32)</li>      <li>complex128 (real and imaginary parts as float64)</li>    </ul>  </li>  <li>    <p><b>Other Numeric Types</b>:</p>    <ul>      <li>rune (alias for int32, represents Unicode code points)</li>    </ul>  </li></ol><h4><b>Boolean</b></h4><ul>  <li>bool      <ul>        <li>Values: true or false.</li>      </ul>  </li></ul><h4><b>String</b></h4><ul>  <li>string      <ul>        <li>Represents a sequence of bytes (characters).</li>        <li>Immutable in Go.</li>      </ul>  </li></ul><hr><h3><b>2. Aggregate Types</b></h3><ol>  <li>    <p><b>Array</b>:</p>    <ul>      <li>Fixed-size collection of elements of the same type.          <pre><p dir=\"ltr\">var arr [5]int  </p>  </pre>      </li>    </ul>  </li>  <li>    <p><b>Slice</b>:</p>    <ul>      <li>Dynamically-sized, flexible view into an array.          <pre><p dir=\"ltr\">var slice []int  slice = append(slice, 10)  </p>  </pre>      </li>    </ul>  </li>  <li>    <p><b>Struct</b>:</p>    <ul>      <li>Collection of fields.          <pre><p dir=\"ltr\">type Person struct {        Name string      Age  int    }  </p>  </pre>      </li>    </ul>  </li></ol><hr><h3><b>3. Reference Types</b></h3><ol>  <li>    <p><b>Pointer</b>:</p>    <ul>      <li>Stores the memory address of a value.          <pre><p dir=\"ltr\">var ptr *int  </p>  </pre>      </li>    </ul>  </li>  <li>    <p><b>Function</b>:</p>    <ul>      <li>Functions are first-class citizens in Go and can be assigned to variables or passed as arguments.</li>    </ul>  </li>  <li>    <p><b>Map</b>:</p>    <ul>      <li>Key-value pairs, similar to dictionaries in Python.          <pre><p dir=\"ltr\">var m map[string]int  </p>  </pre>      </li>    </ul>  </li>  <li>    <p><b>Channel</b>:</p>    <ul>      <li>Used for communication between goroutines.          <pre><p dir=\"ltr\">var ch chan int  </p>  </pre>      </li>    </ul>  </li></ol><hr><h3><b>4. Interface Types</b></h3><ul>  <li>Define a set of methods that a type must implement.      <pre><p dir=\"ltr\">type Shape interface { Area() float64  }  </p>  </pre>  </li></ul><hr><h3><b>Type Conversion</b></h3><p>Go is strictly typed, so explicit conversion is required between types.</p><pre><p dir=\"ltr\">var a int = 10  var b float64 = float64(a)<br></p></pre><hr><h3><b>Example Usage</b></h3><pre><p dir=\"ltr\">package main    import \"fmt\"    <br>func main() {      <br>var age int = 25      <br>var price float64 = 19.99      <br>var name string = \"GoLang\"      <br>var active bool = true        <br>fmt.Println(\"Name:\", name)      <br>fmt.Println(\"Age:\", age)      <br>fmt.Println(\"Price:\", price)      <br>fmt.Println(\"Active:\", active)  <br>}<br></p></pre><p>If you\'d like a deeper dive into a specific type, let me know!</p>', '', '', '', '', '8', 1, '2024-12-28 13:38:19'),
(9, 1, 7, 'Basic Syntax in GoLang', '<p>GoLang\'s syntax is designed to be simple, readable, and efficient. Below is an overview of its basic syntax:</p><hr><h3><b>1. Structure of a Go Program</b></h3><pre><p dir=\"ltr\">package main // Defines the package name; \'main\' is the entry point for the application    import \"fmt\" // Import standard or third-party libraries    func main() { // Entry point of the program      fmt.Println(\"Hello, World!\") // Print output to the console  }  </p></pre><hr><h3><b>2. Comments</b></h3><ul>  <li>    <p><b>Single-line Comment</b>:</p>    <pre><p dir=\"ltr\">// This is a single-line comment  </p></pre>  </li>  <li>    <p><b>Multi-line Comment</b>:</p>    <pre><p dir=\"ltr\">/*This is a multi-line comment. It spans multiple lines. */  </p></pre>  </li></ul><hr><h3><b>3. Variables</b></h3><ul>  <li>    <p><b>Declaring Variables</b>:</p>    <pre><p dir=\"ltr\">var x int // Declares a variable \'x\' of type int  var y = 10 // Type inference, \'y\' is inferred to be int  z := 20 // Short-hand declaration, works only inside functions  </p></pre>  </li>  <li>    <p><b>Multiple Variable Declaration</b>:</p>    <pre><p dir=\"ltr\">var a, b, c int = 1, 2, 3  var d, e = \"Hello\", true  </p></pre>  </li></ul><hr><h3><b>4. Constants</b></h3><ul>  <li>Declared using const, and values must be assigned at compile time.      <pre><p dir=\"ltr\">const Pi = 3.14  const Greeting = \"Hello, Go!\"  </p>  </pre>  </li></ul><hr><h3><b>5. Data Types</b></h3><ul>  <li><b>Primitive Types</b>: int, float64, bool, string</li>  <li><b>Composite Types</b>: array, slice, map, struct</li></ul><hr><h3><b>6. Functions</b></h3><ul>  <li>    <p><b>Defining a Function</b>:</p>    <pre><p dir=\"ltr\">func add(a int, b int) int {return a + b  }  </p></pre>  </li>  <li>    <p><b>Calling a Function</b>:</p>    <pre><p dir=\"ltr\">result := add(5, 3)  fmt.Println(result) // Output: 8  </p></pre>  </li></ul><hr><h3><b>7. Conditional Statements</b></h3><ul>  <li>    <p><b>If-Else</b>:</p>    <pre><p dir=\"ltr\">if x &gt; 10 {      fmt.Println(\"x is greater than 10\")  } else if x == 10 {      fmt.Println(\"x is 10\")  } else {      fmt.Println(\"x is less than 10\")  }  </p></pre>  </li>  <li>    <p><b>Switch</b>:</p>    <pre><p dir=\"ltr\">switch day {  case 1:      fmt.Println(\"Monday\")  case 2:      fmt.Println(\"Tuesday\")  default:      fmt.Println(\"Another day\")  }  </p></pre>  </li></ul><hr><h3><b>8. Loops</b></h3><ul>  <li>    <p><b>For Loop</b>:</p>    <pre><p dir=\"ltr\">for i := 0; i &lt; 5; i++ {      fmt.Println(i)  }  </p></pre>  </li>  <li>    <p><b>For-Range</b> (used with collections):</p>    <pre><p dir=\"ltr\">arr := []int{10, 20, 30}  for index, value := range arr {      fmt.Printf(\"Index: %d, Value: %d\\n\", index, value)  }  </p></pre>  </li></ul><hr><h3><b>9. Arrays and Slices</b></h3><ul>  <li>    <p><b>Array</b>:</p>    <pre><p dir=\"ltr\">var arr [3]int = [3]int{1, 2, 3}  fmt.Println(arr) // Output: [1 2 3]  </p></pre>  </li>  <li>    <p><b>Slice</b>:</p>    <pre><p dir=\"ltr\">slice := []int{1, 2, 3}  slice = append(slice, 4)  fmt.Println(slice) // Output: [1 2 3 4]  </p></pre>  </li></ul><hr><h3><b>10. Maps</b></h3><pre><p dir=\"ltr\">m := make(map[string]int)  m[\"age\"] = 25  fmt.Println(m[\"age\"]) // Output: 25  </p></pre><hr><h3><b>11. Pointers</b></h3><pre><p dir=\"ltr\">var x = 10  var ptr = &amp;x // \'ptr\' stores the memory address of \'x\'  fmt.Println(*ptr) // Output: 10  </p></pre><hr><h3><b>12. Concurrency</b></h3><ul>  <li>    <p><b>Goroutines</b>:</p>    <pre><p dir=\"ltr\">go func() {fmt.Println(\"This runs in a goroutine\")  }()  </p></pre>  </li>  <li>    <p><b>Channels</b>:</p>    <pre><p dir=\"ltr\">ch := make(chan int)  go func() { ch &lt;- 5 }()  fmt.Println(&lt;-ch) // Output: 5  </p></pre>  </li></ul><hr><h3><b>13. Error Handling</b></h3><ul>  <li><b>Using error Interface</b>:      <pre><p dir=\"ltr\">  import \"errors\"      func divide(a, b int) (int, error) {        if b == 0 {return 0, errors.New(\"division by zero\")        }return a / b, nil  }  </p>  </pre>  </li></ul><hr><p>This covers the basic syntax of GoLang. Let me know if you\'d like more detailed explanations or examples on any topic!</p>', '', '', '', '', '', 1, '2024-12-28 18:43:07');

-- --------------------------------------------------------

--
-- Table structure for table `itio_tutorial_menu`
--

CREATE TABLE `itio_tutorial_menu` (
  `id` int(11) NOT NULL,
  `title_id` int(11) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `status` int(1) DEFAULT 1,
  `addedby` int(11) DEFAULT NULL,
  `addedon` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_tutorial_menu`
--

INSERT INTO `itio_tutorial_menu` (`id`, `title_id`, `title`, `status`, `addedby`, `addedon`) VALUES
(1, 2, 'ppppp', 2, NULL, '2024-11-27 11:25:47'),
(2, 2, 'hhhhhhhhh', 2, NULL, '2024-11-27 11:25:52'),
(3, 1, 'Home', 1, NULL, '2024-11-27 11:20:56'),
(4, 1, 'Overview', 1, NULL, '2024-11-27 11:22:05'),
(5, 1, 'Environment Setup', 1, NULL, '2024-11-27 11:22:09'),
(6, 1, 'Program Structure', 1, NULL, '2024-11-27 11:22:20'),
(7, 1, 'Basic Syntax', 1, NULL, '2024-11-27 11:22:28'),
(8, 1, 'Data Types', 1, NULL, '2024-11-27 11:22:38'),
(9, 1, 'Variables', 1, NULL, '2024-11-27 11:22:48'),
(10, 1, 'Constants', 1, NULL, '2024-11-27 11:22:55'),
(11, 1, 'Operators', 1, NULL, '2024-11-27 11:23:02'),
(12, 1, 'Decision Making', 1, NULL, '2024-11-27 11:23:12'),
(13, 1, 'Loops', 1, NULL, '2024-11-27 11:23:19'),
(14, 1, 'Functions', 1, NULL, '2024-11-27 11:23:27'),
(15, 1, 'Scope Rules', 1, NULL, '2024-11-27 11:23:36'),
(16, 1, 'Strings', 1, NULL, '2024-11-27 11:23:51'),
(17, 1, 'Arrays', 1, NULL, '2024-11-27 11:24:07'),
(18, 1, 'Pointers', 1, NULL, '2024-11-27 11:24:15'),
(19, 1, 'Structures', 1, NULL, '2024-11-27 11:24:24'),
(20, 1, 'Slice', 1, NULL, '2024-11-27 11:24:30'),
(21, 1, 'Range', 1, NULL, '2024-11-27 11:24:37'),
(22, 1, 'Maps', 1, NULL, '2024-11-27 11:24:45'),
(23, 1, 'Recursion', 1, NULL, '2024-11-27 11:24:51'),
(24, 1, 'Type Casting', 1, NULL, '2024-11-27 11:25:04'),
(25, 1, 'Interfaces', 1, NULL, '2024-11-27 11:25:13'),
(26, 1, 'Error Handling', 1, NULL, '2024-11-27 11:25:22'),
(27, 1, 'Go Useful Resources', 1, NULL, '2024-11-27 11:25:32'),
(28, 1, 'Questions and Answers', 1, NULL, '2024-11-27 11:25:40'),
(29, 7, 'HOME', 1, NULL, '2024-12-26 04:36:34'),
(30, 7, 'Intro', 1, NULL, '2024-12-26 04:37:21'),
(31, 7, 'RDBMS', 1, NULL, '2024-12-26 04:37:30'),
(32, 7, 'SQL', 1, NULL, '2024-12-26 04:37:41'),
(33, 7, 'SELECT', 1, NULL, '2024-12-26 04:37:46'),
(34, 7, 'WHERE', 1, NULL, '2024-12-26 04:37:52'),
(35, 7, 'AND, OR, NOT', 1, NULL, '2024-12-26 04:38:06'),
(36, 7, 'ORDER BY', 1, NULL, '2024-12-26 04:38:17'),
(37, 7, 'INSERT INTO', 1, NULL, '2024-12-26 04:38:26'),
(38, 7, 'NULL Values', 1, NULL, '2024-12-26 04:38:36'),
(39, 7, 'UPDATE', 1, NULL, '2024-12-26 04:38:46'),
(40, 7, 'DELETE', 1, NULL, '2024-12-26 04:38:57'),
(41, 7, 'LIMIT', 1, NULL, '2024-12-26 04:39:59'),
(42, 7, 'MIN and MAX', 1, NULL, '2024-12-26 04:40:11'),
(43, 7, 'COUNT, AVG, SUM', 1, NULL, '2024-12-26 04:40:22'),
(44, 7, 'LIKE', 1, NULL, '2024-12-26 04:40:31'),
(45, 7, 'Wildcards', 1, NULL, '2024-12-26 04:40:38'),
(46, 7, 'IN', 1, NULL, '2024-12-26 04:40:47'),
(47, 7, 'BETWEEN', 1, NULL, '2024-12-26 04:40:55'),
(48, 7, 'Aliases', 1, NULL, '2024-12-26 04:41:02'),
(49, 7, 'Joins', 1, NULL, '2024-12-26 04:41:11'),
(50, 7, 'INNER JOIN', 1, NULL, '2024-12-26 04:41:20'),
(51, 7, 'LEFT JOIN', 1, NULL, '2024-12-26 04:41:29'),
(52, 7, 'RIGHT JOIN', 1, NULL, '2024-12-26 04:41:37'),
(53, 7, 'CROSS JOIN', 1, NULL, '2024-12-26 04:41:48'),
(54, 7, 'Self Join', 1, NULL, '2024-12-26 04:41:58'),
(55, 7, 'UNION', 1, NULL, '2024-12-26 04:42:13'),
(56, 7, 'GROUP BY', 1, NULL, '2024-12-26 04:42:22'),
(57, 7, 'HAVING', 1, NULL, '2024-12-29 10:10:16'),
(58, 7, 'EXISTS', 1, NULL, '2024-12-29 10:11:02'),
(59, 7, 'ANY, ALL', 1, NULL, '2024-12-29 10:11:18'),
(60, 7, 'INSERT SELECT', 1, NULL, '2024-12-29 10:12:23'),
(61, 7, 'CASE', 1, NULL, '2024-12-29 10:12:39'),
(62, 7, 'Null Functions', 1, NULL, '2024-12-29 10:12:54'),
(63, 7, 'Comments', 1, NULL, '2024-12-29 10:13:16'),
(64, 7, 'Operators', 1, NULL, '2024-12-29 10:13:32'),
(65, 25, 'Home', 1, NULL, '2024-12-30 07:27:24'),
(66, 25, 'Overview', 1, NULL, '2024-12-30 07:27:27'),
(67, 25, 'Environment Setup', 1, NULL, '2024-12-30 07:27:36'),
(68, 25, 'Architecture', 1, NULL, '2024-12-30 07:27:48'),
(69, 25, 'Basic Syntax', 1, NULL, '2024-12-30 07:27:57'),
(70, 25, 'Comments', 1, NULL, '2024-12-30 07:28:11'),
(71, 25, 'Keywords', 1, NULL, '2024-12-30 07:28:34'),
(72, 25, 'Variables', 1, NULL, '2024-12-30 07:28:45'),
(73, 25, 'Data Types', 1, NULL, '2024-12-30 07:28:55'),
(74, 25, 'Operators', 1, NULL, '2024-12-30 07:29:53'),
(75, 25, 'Booleans', 1, NULL, '2024-12-30 07:30:01'),
(76, 25, 'Strings', 1, NULL, '2024-12-30 07:30:13'),
(77, 25, 'Arrays', 1, NULL, '2024-12-30 07:30:23'),
(78, 25, 'Ranges', 1, NULL, '2024-12-30 07:30:32'),
(79, 25, 'Functions', 1, NULL, '2024-12-30 07:30:41'),
(80, 25, 'Control Flow', 1, NULL, '2024-12-30 07:30:50'),
(81, 25, 'if Else Expression', 1, NULL, '2024-12-30 07:30:59'),
(82, 25, 'When Expression', 1, NULL, '2024-12-30 07:31:08'),
(83, 25, 'For Loop', 1, NULL, '2024-12-30 07:31:17'),
(84, 25, 'While Loop', 1, NULL, '2024-12-30 07:31:32'),
(85, 25, 'Break and Continue', 1, NULL, '2024-12-30 07:32:07'),
(86, 25, 'Collections', 1, NULL, '2024-12-30 07:32:19'),
(87, 25, 'Lists', 1, NULL, '2024-12-30 07:32:31'),
(88, 25, 'Sets', 1, NULL, '2024-12-30 07:32:40'),
(89, 25, 'Maps', 1, NULL, '2024-12-30 07:32:50'),
(90, 25, 'Class and Objects', 1, NULL, '2024-12-30 07:33:02'),
(91, 25, 'Constructors', 1, NULL, '2024-12-30 07:33:11'),
(92, 25, 'Inheritance', 1, NULL, '2024-12-30 07:33:26'),
(93, 25, 'Abstract Classes', 1, NULL, '2024-12-30 07:33:35'),
(94, 25, 'Interface', 1, NULL, '2024-12-30 07:33:49'),
(95, 25, 'Visibility Control', 1, NULL, '2024-12-30 07:34:00'),
(96, 25, 'Extension', 1, NULL, '2024-12-30 07:34:31'),
(97, 25, 'Data Classes', 1, NULL, '2024-12-30 07:34:42'),
(98, 25, 'Sealed Class', 1, NULL, '2024-12-30 07:34:50'),
(99, 25, 'Generics', 1, NULL, '2024-12-30 07:34:59'),
(100, 25, 'Delegation', 1, NULL, '2024-12-30 07:35:11'),
(101, 25, 'Destructuring Declarations', 1, NULL, '2024-12-30 07:35:27'),
(102, 25, 'Exception Handling', 1, NULL, '2024-12-30 07:35:38'),
(103, 3, 'Features', 1, NULL, '2024-12-30 07:39:40'),
(104, 3, 'Docker architecture', 1, NULL, '2024-12-30 07:39:52'),
(105, 3, 'Installation on Ubuntu', 1, NULL, '2024-12-30 07:40:01'),
(106, 3, 'Installation on Windows', 1, NULL, '2024-12-30 07:40:11'),
(107, 3, 'Image & Container', 1, NULL, '2024-12-30 07:40:20'),
(108, 3, 'Dockerfile', 1, NULL, '2024-12-30 07:40:29'),
(109, 3, 'Java Example', 1, NULL, '2024-12-30 07:40:44'),
(110, 3, 'Php Example', 1, NULL, '2024-12-30 07:40:56'),
(111, 3, 'Python Example', 1, NULL, '2024-12-30 07:41:06'),
(112, 3, 'Scala Example', 1, NULL, '2024-12-30 07:41:16'),
(113, 3, 'Perl Example', 1, NULL, '2024-12-30 07:41:51'),
(114, 3, 'Ruby Example', 1, NULL, '2024-12-30 07:42:01'),
(115, 3, 'Swift Example', 1, NULL, '2024-12-30 07:42:13'),
(116, 3, 'Ubuntu Example', 1, NULL, '2024-12-30 07:42:42'),
(117, 3, 'Push Repository', 1, NULL, '2024-12-30 07:42:54'),
(118, 3, 'Useful Commands', 1, NULL, '2024-12-30 07:43:05'),
(119, 3, 'Cloud', 1, NULL, '2024-12-30 07:43:14'),
(120, 3, 'Compose', 1, NULL, '2024-12-30 07:43:22'),
(121, 3, 'Storage Driver', 1, NULL, '2024-12-30 07:43:32'),
(122, 3, 'Docker vs Kubernetes', 1, NULL, '2024-12-30 07:44:13'),
(123, 5, 'HOME', 1, NULL, '2024-12-30 12:10:24'),
(124, 5, 'Tutorial', 1, NULL, '2024-12-30 12:10:26'),
(125, 5, 'Get Started', 1, NULL, '2024-12-30 12:10:34'),
(126, 5, 'Query API', 1, NULL, '2024-12-30 12:10:43'),
(127, 5, 'Create DB', 1, NULL, '2024-12-30 12:10:55'),
(128, 5, 'Collection', 1, NULL, '2024-12-30 12:11:13'),
(129, 5, 'Insert', 1, NULL, '2024-12-30 12:11:33'),
(130, 5, 'Find', 1, NULL, '2024-12-30 12:11:41'),
(131, 5, 'Update', 1, NULL, '2024-12-30 12:11:51'),
(132, 5, 'Delete', 1, NULL, '2024-12-30 12:12:00'),
(133, 5, 'Query Operators', 1, NULL, '2024-12-30 12:12:14'),
(134, 5, 'Update Operators', 1, NULL, '2024-12-30 12:16:06'),
(135, 5, 'Aggregations', 1, NULL, '2024-12-30 12:16:16'),
(136, 5, 'Indexing OR Search', 1, NULL, '2024-12-30 12:16:34'),
(137, 5, 'Validation', 1, NULL, '2024-12-30 12:16:41'),
(138, 5, 'Data API', 1, NULL, '2024-12-30 12:16:49'),
(139, 5, 'Drivers', 1, NULL, '2024-12-30 12:16:58'),
(140, 5, 'Node.js Driver', 1, NULL, '2024-12-30 12:17:08'),
(141, 5, 'Charts', 1, NULL, '2024-12-30 12:17:16'),
(142, 6, 'Home', 1, NULL, '2024-12-30 12:20:01'),
(143, 6, 'Intro', 1, NULL, '2024-12-30 12:20:08'),
(144, 6, 'Install', 1, NULL, '2024-12-30 12:20:14'),
(145, 6, 'Get Started', 1, NULL, '2024-12-30 12:20:24'),
(146, 6, 'pgAdmin 4', 1, NULL, '2024-12-30 12:20:33'),
(147, 6, 'CREATE TABLE', 1, NULL, '2024-12-30 12:20:42'),
(148, 6, 'INSERT INTO', 1, NULL, '2024-12-30 12:20:51'),
(149, 6, 'Fetch Data', 1, NULL, '2024-12-30 12:21:00'),
(150, 6, 'ADD COLUMN', 1, NULL, '2024-12-30 12:21:08'),
(151, 6, 'UPDATE', 1, NULL, '2024-12-30 12:21:15'),
(152, 6, 'ALTER COLUMN', 1, NULL, '2024-12-30 12:21:53'),
(153, 6, 'DROP COLUMN', 1, NULL, '2024-12-30 12:22:00'),
(154, 6, 'DELETE', 1, NULL, '2024-12-30 12:22:08'),
(155, 6, 'DROP TABLE', 1, NULL, '2024-12-30 12:22:17'),
(156, 6, 'Syntax', 1, NULL, '2024-12-30 12:22:32'),
(157, 6, 'Operators', 1, NULL, '2024-12-30 12:22:40'),
(158, 6, 'SELECT', 1, NULL, '2024-12-30 12:22:50'),
(159, 6, 'SELECT DISTINCT', 1, NULL, '2024-12-30 12:23:02'),
(160, 6, 'WHERE', 1, NULL, '2024-12-30 12:23:14'),
(161, 6, 'ORDER BY', 1, NULL, '2024-12-30 12:23:23'),
(162, 6, 'LIMIT', 1, NULL, '2024-12-30 12:24:18'),
(163, 6, 'MIN and MAX', 1, NULL, '2024-12-30 12:24:25'),
(164, 6, 'COUNT', 1, NULL, '2024-12-30 12:24:33'),
(165, 6, 'SUM', 1, NULL, '2024-12-30 12:24:39'),
(166, 6, 'AVG', 1, NULL, '2024-12-30 12:24:44'),
(167, 6, 'LIKE', 1, NULL, '2024-12-30 12:24:51'),
(168, 6, 'IN', 1, NULL, '2024-12-30 12:24:57'),
(169, 6, 'BETWEEN', 1, NULL, '2024-12-30 12:25:03'),
(170, 6, 'AS', 1, NULL, '2024-12-30 12:25:08'),
(171, 6, 'Joins', 1, NULL, '2024-12-30 12:25:14'),
(172, 6, 'INNER JOIN', 1, NULL, '2024-12-30 12:26:09'),
(173, 6, 'LEFT JOIN', 1, NULL, '2024-12-30 12:26:20'),
(174, 6, 'RIGHT JOIN', 1, NULL, '2024-12-30 12:26:30'),
(175, 6, 'FULL JOIN', 1, NULL, '2024-12-30 12:26:42'),
(176, 6, 'CROSS JOIN', 1, NULL, '2024-12-30 12:26:51'),
(177, 6, 'UNION', 1, NULL, '2024-12-30 12:26:58'),
(178, 6, 'GROUP BY', 1, NULL, '2024-12-30 12:31:08'),
(179, 6, 'HAVING', 1, NULL, '2024-12-30 12:31:11'),
(180, 6, 'EXISTS', 1, NULL, '2024-12-30 12:31:20'),
(181, 6, 'ANY', 1, NULL, '2024-12-30 12:31:25'),
(182, 6, 'ALL', 1, NULL, '2024-12-30 12:31:30'),
(183, 6, 'CASE', 1, NULL, '2024-12-30 12:31:36');

-- --------------------------------------------------------

--
-- Table structure for table `itio_tutorial_title`
--

CREATE TABLE `itio_tutorial_title` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `priority` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itio_tutorial_title`
--

INSERT INTO `itio_tutorial_title` (`id`, `title`, `icon`, `status`, `priority`) VALUES
(1, 'GoLang', '', 1, 0),
(2, 'PHP', '', 1, 0),
(3, 'Docker', '', 1, 0),
(4, 'kubernetes', '', 1, 0),
(5, 'MongoDB', '', 1, 0),
(6, 'PostgreSql', '', 1, 0),
(7, 'MySql', '', 1, 0),
(8, 'SQL', '', 1, 0),
(9, 'HTML', '', 1, 0),
(10, 'CSS', '', 1, 0),
(11, 'JavaScript', '', 1, 0),
(12, 'Jquery', '', 1, 0),
(13, 'Ajax', '', 1, 0),
(14, 'Bootstrap', '', 1, 0),
(15, 'Git', '', 1, 0),
(16, 'AWS', '', 1, 0),
(17, 'Azure', '', 1, 0),
(18, 'GCP', '', 1, 0),
(19, 'TypeScript', '', 1, 0),
(20, 'ReactJS', '', 1, 0),
(21, 'NextJS', '', 1, 0),
(22, 'NodeJs', '', 1, 0),
(23, 'Java', '', 1, 0),
(24, 'Python', '', 1, 0),
(25, 'Kotlin', '', 1, 0),
(26, 'MariaDB', '', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `itio_activity`
--
ALTER TABLE `itio_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itio_admin`
--
ALTER TABLE `itio_admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `admin_user` (`admin_user`);

--
-- Indexes for table `itio_login_master`
--
ALTER TABLE `itio_login_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itio_master_trans_table`
--
ALTER TABLE `itio_master_trans_table`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `itio_menu`
--
ALTER TABLE `itio_menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `itio_submenu`
--
ALTER TABLE `itio_submenu`
  ADD PRIMARY KEY (`submenu_id`);

--
-- Indexes for table `itio_tutorial_master`
--
ALTER TABLE `itio_tutorial_master`
  ADD PRIMARY KEY (`tutorial_id`);

--
-- Indexes for table `itio_tutorial_menu`
--
ALTER TABLE `itio_tutorial_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itio_tutorial_title`
--
ALTER TABLE `itio_tutorial_title`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `itio_activity`
--
ALTER TABLE `itio_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=213;

--
-- AUTO_INCREMENT for table `itio_admin`
--
ALTER TABLE `itio_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `itio_login_master`
--
ALTER TABLE `itio_login_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `itio_master_trans_table`
--
ALTER TABLE `itio_master_trans_table`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `itio_menu`
--
ALTER TABLE `itio_menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `itio_submenu`
--
ALTER TABLE `itio_submenu`
  MODIFY `submenu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `itio_tutorial_master`
--
ALTER TABLE `itio_tutorial_master`
  MODIFY `tutorial_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `itio_tutorial_menu`
--
ALTER TABLE `itio_tutorial_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=184;

--
-- AUTO_INCREMENT for table `itio_tutorial_title`
--
ALTER TABLE `itio_tutorial_title`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
